<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangesInSupplierAcc extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('supplieracc',function(Blueprint $table)
        {
           DB::statement('ALTER TABLE supplieracc MODIFY `fc_contactperson` varchar(191), MODIFY `fc_phone` varchar(191), MODIFY `fc_mobile` varchar(191), MODIFY `fc_mailid` varchar(191), MODIFY `qt_contactperson` varchar(191), MODIFY `qt_phone` varchar(191), MODIFY `qt_mobile` varchar(191), MODIFY `qt_mailid` varchar(191), MODIFY `ohqo_contactperson` varchar(191), MODIFY `ohqo_phone` varchar(191), MODIFY `ohqo_mobile` varchar(191), MODIFY `ohqo_mailid` varchar(191), MODIFY `ac_contactperson` varchar(191), MODIFY `ac_phone` varchar(191), MODIFY `ac_mobile` varchar(191), MODIFY `ac_mailid` varchar(191), MODIFY `dd_contactperson` varchar(191), MODIFY `dd_phone` varchar(191), MODIFY `dd_mobile` varchar(191), MODIFY `dd_mailid` varchar(191), MODIFY `bank_details` varchar(191), MODIFY `overall_capability` varchar(191), MODIFY `referenceclients` varchar(191), MODIFY `creditterms` varchar(191), MODIFY `supply_s` tinyint(4), MODIFY `supply_directly` tinyint(1), MODIFY `provide_dealer` longtext');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
