<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class EnquiryDbCreate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('enquiries', function(Blueprint $table){
            $table->increments('id');
            $table->date('enquiry_date');
            $table->string('rfq_number');
            $table->string('rbs_offer_number');
            $table->string('offer_value');
            $table->string('customer');
            $table->longText('description');
            $table->string('status');
            $table->integer('emp_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
