<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatSupplierAccreditionform extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('supplieracc', function(Blueprint $table)
        {
            $table->increments('id');
            $table->string('company_name');
            $table->string('sm_contactperson');
            $table->string('sm_phone');
            $table->string('sm_mobile');
            $table->string('sm_mailid');
            $table->string('fc_contactperson');
            $table->string('fc_phone');
            $table->string('fc_mobile');
            $table->string('fc_mailid');
            $table->string('qt_contactperson');
            $table->string('qt_phone');
            $table->string('qt_mobile');
            $table->string('qt_mailid');
            $table->string('ohqo_contactperson');
            $table->string('ohqo_phone');
            $table->string('ohqo_mobile');
            $table->string('ohqo_mailid');
            $table->string('ac_contactperson');
            $table->string('ac_phone');
            $table->string('ac_mobile');
            $table->string('ac_mailid');
            $table->string('dd_contactperson');
            $table->string('dd_phone');
            $table->string('dd_mobile');
            $table->string('dd_mailid');
            $table->string('bank_details');
            $table->string('gstin');
            $table->string('overall_capability');
            $table->string('referenceclients');
            $table->string('creditterms');
            $table->boolean('manufacture_dealer');
            $table->boolean('supply_directly');
            $table->boolean('provide_dealer');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
