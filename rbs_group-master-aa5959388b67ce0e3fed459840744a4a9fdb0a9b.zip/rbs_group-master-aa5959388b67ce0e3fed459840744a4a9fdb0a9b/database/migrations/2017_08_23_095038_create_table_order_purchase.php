<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableOrderPurchase extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchase_order', function(Blueprint $table)
        {
            $table->increments('id');
            $table->date('po_date');
            $table->string('po_number');
            $table->string('rbs_offer_number');
            $table->string('po_offer_value');
            $table->string('customer');
            $table->longText('description');
            $table->string('notes_remarks');
            $table->string('status');
            $table->integer('emp_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
