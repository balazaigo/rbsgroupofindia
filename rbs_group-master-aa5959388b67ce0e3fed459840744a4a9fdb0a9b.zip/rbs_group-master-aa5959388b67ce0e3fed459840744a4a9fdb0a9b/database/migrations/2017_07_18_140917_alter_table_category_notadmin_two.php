<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterTableCategoryNotadminTwo extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       Schema::table('cat', function(Blueprint $table){
             $table->dropColumn('category_name');
             $table->dropColumn('catid');
             $table->dropColumn('childid');
             $table->integer('vid')->after('id');
             $table->integer('cid')->after('vid');

       });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
