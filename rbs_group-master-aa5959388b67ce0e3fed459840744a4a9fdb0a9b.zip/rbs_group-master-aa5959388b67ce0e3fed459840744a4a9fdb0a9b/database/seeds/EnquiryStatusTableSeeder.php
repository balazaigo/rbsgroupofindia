<?php

use Illuminate\Database\Seeder;

class EnquiryStatusTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //DB::table('enquiry_status')->insert(['id'=>1, 'status'=>'open,close,new', 'status_vendor'=>'open,close']);
        \App\Enquirystatus::create([
            'id'=>1,
            'status'=>'open,close,new',
            'status_vendor'=>'open,close'
        ]);
    }
}
