<?php

use Illuminate\Database\Seeder;
use App\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
            User::create([
                'name' => 'RBS admin',
                'email' => 'rbsgroupindia@gmail.com',
                'password' => bcrypt('rbspass'),
                'urole' => 1,
            ]);

            User::create([
                'name' => 'RBS Staff 1',
                'email' => 'rbsstaff1@gmail.com',
                'password' => bcrypt('rbspass'),
                'urole' => 2,
            ]);

            User::create([
                'name' => 'RBS Staff 2',
                'email' => 'rbsstaff2@gmail.com',
                'password' => bcrypt('rbspass'),
                'urole' => 2,
            ]);
    }
}
