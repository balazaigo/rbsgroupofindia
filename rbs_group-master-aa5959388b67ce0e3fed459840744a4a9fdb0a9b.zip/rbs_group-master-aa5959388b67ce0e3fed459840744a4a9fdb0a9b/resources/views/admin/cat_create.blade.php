@extends('layouts.admin')

@section('content')
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>
                        @if(@$edit)
                            Edit Category
                        @else
                            New Category
                        @endif
                    </h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <br />
                    <form id="demo-form2" method="post" @if(@$edit) action="{{ URL::to('rbsadmin/category/'.$edit['id']) }}" @else action="{{ URL::to('rbsadmin/category') }}" @endif data-parsley-validate class="form-horizontal form-label-left">
                        {{ FORM::token() }}
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Name
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" name="cat_name" id="first-name" @if(@$edit) value="{{ $edit['cat_name'] ? $edit['cat_name'] : old('cat_name') }}" @else value="{{ old('cat_name') }}" @endif placeholder="Category Name" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>
                        @if(!@$edit)
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Parent Category
                            </label>
                            <div class="col-md-6 col-xs-6 col-xs-12">
                            <select name="parent_id" class="form-control">
                                <option value="0" selected="selected">--Select Parent--</option>
                                @foreach($cat as $category)
                                    <option value="{{ $category['id'] }}" >{{ $category['cat_name'] }}</option>
                                @endforeach
                            </select>
                            </div>
                        </div>
                        @endif
                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <a href="{{ URL::to('rbsadmin/category') }}" class="btn btn-primary">Back</a>
                                @if(@$edit)

                                    <input type="hidden" name="_method" value="put" />
                                    <button type="submit" class="btn btn-success">Edit</button>

                                @else
                                    <button type="submit" class="btn btn-success">Create</button>
                                @endif
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection