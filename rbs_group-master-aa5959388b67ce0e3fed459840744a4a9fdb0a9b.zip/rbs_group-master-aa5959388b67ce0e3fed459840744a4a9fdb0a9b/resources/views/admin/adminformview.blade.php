@extends('layouts.admin')

@section('content')


<div class="container">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>{{ $view_data['company_name'] }} info</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <br />
                <form class="form-horizontal form-label-left">
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Company Name :</label>
                        <div class="checkbox">
                            <label>{{ $view_data['company_name'] }} </label>
                        </div>
                    </div>
                    <div class="x_title">
                        <h2>{{ "SALES AND MARKETING" }}</h2>
                        <div class="clearfix"></div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Contact Person: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['sm_contactperson'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Phone: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['sm_phone'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Mobile: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['sm_mobile'] }} </label>
                            </div>

                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">e-Mail: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['sm_mailid'] }} </label>
                            </div>
                    </div>
                    <div class="x_title">
                        <h2>{{ "FACTORY CONTACT" }}</h2>
                        <div class="clearfix"></div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Contact Person: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['fc_contactperson'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Phone: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['fc_phone'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Mobile: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['fc_mobile'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">e-Mail: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['fc_mailid'] }} </label>
                            </div>
                    </div>
                    <div class="x_title">
                        <h2>{{ "QUALITY TEAM" }}</h2>
                        <div class="clearfix"></div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Contact Person: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['qt_contactperson'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Phone: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['qt_phone'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Mobile: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['qt_mobile'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">e-Mail: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['qt_mailid'] }} </label>
                            </div>
                    </div>
                    <div class="x_title">
                        <h2>{{ "Overall Head / Quality Operations" }}</h2>
                        <div class="clearfix"></div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Contact Person: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['ohqo_contactperson'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Phone: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['ohqo_phone'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Mobile: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['ohqo_mobile'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">e-Mail: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['ohqo_mailid'] }} </label>
                            </div>
                    </div>
                    <div class="x_title">
                        <h2>{{ "ACCOUNTS" }}</h2>
                        <div class="clearfix"></div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Contact Person: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['ac_contactperson'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Phone: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['ac_phone'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Mobile: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['ac_mobile'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">e-Mail: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['ac_mailid'] }} </label>
                            </div>
                    </div>
                    <div class="x_title">
                        <h2>{{ "DELIVERY DISPATCH" }}</h2>
                        <div class="clearfix"></div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Contact Person: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['dd_contactperson'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Phone: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['dd_phone'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Mobile: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['dd_mobile'] }} </label>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">e-Mail: </label>
                            <div class="checkbox">
                                <label>{{ $view_data['dd_mailid'] }} </label>
                            </div>
                    </div>

                    <div class="x_title">
                        <h2>{{ "Banking Details" }}</h2>
                        <div class="clearfix"></div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">BANKING DETAILS</label>
                            <div class="checkbox">
                                <label>{{ $view_data['bank_details'] }} </label>
                            </div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">GSTIN</label>
                            <div class="checkbox">
                                <label>{{ $view_data['gstin'] }} </label>
                            </div>
                    </div>
                    <div class="x_title">
                        <h2>{{ "Client Details" }}</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Overall Capability</label>
                            <div class="checkbox">
                                <label>{{ $view_data['overall_capability'] }} </label>
                            </div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Reference Clients</label>
                            <div class="checkbox">
                                <label>{{ $view_data['referenceclients'] }} </label>
                            </div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Credit Terms </label>
                            <div class="checkbox">
                                <label>{{ $view_data['creditterms'] }} </label>
                            </div>
                    </div>
                    <div class="x_title">
                        <h2>{{ "Manufacturing Details" }}</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Manufacturer/Dealer: </label>
                            <div class="checkbox">
                                <label>@if(@$view_data['manufacture_dealer']=="2") "Dealer" @else "Manufacturer" @endif </label>
                            </div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Supplying Directly? </label>
                            <div class="checkbox">
                                <label>@if(@$view_data['supply_s']=="2") NO @else Yes @endif </label>
                            </div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Provider/Dealer Details </label>
                            <div class="checkbox">
                                <label> {{ $view_data['provide_dealer'] ? $view_data['provide_dealer'] : "No Dealer Details Provided" }} </label>
                            </div>
                    </div>

                    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Categories </label>
                            <div class="checkbox">
                                @foreach(@$view_d as $val)
                            <label>  {{ $val['cat_name']."," }} </label>
                                @endforeach
                            </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                            <a href="{{ URL::to('rbsadmin/form') }}" class="btn btn-primary">Back</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection