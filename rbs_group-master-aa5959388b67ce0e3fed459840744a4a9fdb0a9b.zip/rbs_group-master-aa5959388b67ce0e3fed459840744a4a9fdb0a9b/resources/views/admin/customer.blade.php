@extends('layouts.admin')

@section('content')

    <div class="title_right">
        <div class="col-md-5 col-sm-5 col-xs-5 form-group pull-right top_search">
            <form method="get" action="{{ URL::to('rbsadmin/customer') }}">
                <div class="input-group">
                    <input type="text" name="search" value = "{{ $retain_search }}" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="submit">Go!</button>

                    </span>

                </div>
            </form>
        </div>
    </div>
    <div class="x_panel">

        <div class="x_title">
            <h2>Customer List</h2>
            <ul class="nav navbar-right panel_toolbox">
                <li><a href="{{ URL::to('rbsadmin/customer/create') }}" class="plus-circle"><i class="fa fa-plus-circle"></i>Add Customer</a></li>
            </ul>
            <div class="clearfix"></div>
    </div>
        <div class="clearfix"></div>
        <div class="col-md-12">

            <div class="table-responsive">


                <table id="mytable" class="table table-bordred table-striped">

                    <thead>
                    <th>S.No</th>
                    <th>Customer Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    </thead>
                        <tbody>
                        <?php $sl_no = 1; ?>
                        @foreach($customer as $val)
                        <tr>
                            {{--<td>{{ $val->id }}</td>--}}

                            <td>{{ $sl_no+$page_quer }}</td>

                            <td>{{ $val->customer_name }}</td>
                            <td><a href="{{ URL::to('rbsadmin/customer/'.$val->id.'/edit') }}" data-placement="top" data-toggle="tooltip" title="Edit"> <button class="vendor-form-edit" type="submit"><i class="fa fa-edit"></i></button></a></td>
                            <td><form method="post" action="{{ URL::to('rbsadmin/customer/'.$val->id) }}">
                                    {{ FORM::token() }}
                                    <input name="_method" type="hidden" value="DELETE">
                                    <button onsubmit="return confirm('are you sure?')" class="vendor-form-delete"><i class="fa fa-trash"></i></button>
                                </form></td>
                        </tr>
                        <?php $sl_no++; ?>
                        @endforeach
                        </tbody>
                </table>
                <div class="clearfix"></div>
                {{ $customer->appends(\Input::except('page'))->render() }}
            </div>
        </div>
    </div>

@endsection