@extends('layouts.admin')

@section('content')
    <div class="x_panel">
        <div class="x_title">
            <h2>@if(@$edit_customer)<h2>{{ "Enquiry Edit" }}</h2>@else <h2>Create Customer</h2>@endif</h2>
            <div class="clearfix"></div>
        </div>
        <form method="post" @if(@$edit_customer) action="{{ URL::to('rbsadmin/customer/'.$edit_customer['id']) }}" @else action="{{ URL::to('rbsadmin/customer') }}" @endif class="form-horizontal form-label-left">
            {{ FORM::token() }}
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">Customer Name<span class="required">*</span>
                </label>
                <div class="col-md-7">
                    <input type="text" name="customer_name" class="form-control col-md-6" @if(@$edit_customer) value="{{ $edit_customer->customer_name }}" @endif placeholder="Customer Name" />
                </div>
            </div>
            <div class="ln_solid"></div>
            <div class="form-group">
                        <a href="{{ URL::to('rbsadmin/customer') }}" class="btn btn-primary">Back</a>
                @if(@$edit_customer)
                    <input type="hidden" name="_method" value="put" />
                    <button class="btn btn-success" type="submit">Edit</button>
                @else
                <button class="btn btn-success" type="submit">Submit</button>
                @endif
            </div>
        </form>
    </div>
@endsection