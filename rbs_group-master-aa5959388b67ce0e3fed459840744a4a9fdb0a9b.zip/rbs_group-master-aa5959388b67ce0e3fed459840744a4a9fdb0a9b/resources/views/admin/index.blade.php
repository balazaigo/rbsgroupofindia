@extends('layouts.admin')


@section('content')
<!-- top tiles -->
<div class="row tile_count">


    <img style="display: block; margin-left: auto; margin-right: auto; margin-top: 10%;" src="{{ asset('images/logo.jpg') }}" alt="...">
    <h3 style="text-align: center;">Welcome To</h3>
    <h1 style="text-align: center;">RBS ADMIN PANEL</h1>
</div>
@endsection