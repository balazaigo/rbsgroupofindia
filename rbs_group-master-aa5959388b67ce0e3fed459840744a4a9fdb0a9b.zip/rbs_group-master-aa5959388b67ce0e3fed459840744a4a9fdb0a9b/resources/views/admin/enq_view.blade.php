@extends('layouts.admin')

@section('content')

<div class="container">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Enquiry List</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <br />

                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Enquiry Date</label>
                        <div class="checkbox">
                            <label>{{ date('d/m/Y', strtotime($view_same['enquiry_date'])) }}</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">RFQ NUMBER</label>
                        <div class="checkbox">
                            <label>{{ $view_same['rfq_number'] }} </label>
                        </div>
                    </div>
                    @if(Auth::user()->urole==1)
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">RBS OFFER NUMBER</label>
                        <div class="checkbox">
                            <label>{{ $view_same['rbs_offer_number'] }} </label>
                        </div>
                    </div>
                    <div class="form-group">

                        <label class="control-label col-md-3 col-sm-3 col-xs-12"> Offer Value </label>
                        <div class="checkbox">
                            <label>{{ $view_same['offer_value'] }}</label>
                        </div>

                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Customer</label>
                        <div class="checkbox">
                            <label>{{ $view_same['customer'] }}</label>
                        </div>
                    </div>
                    @endif

                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Description</label>
                        <div class="checkbox">
                            <label class="desc_img">{!! $view_same['description'] !!}</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Status</label>
                        <div class="checkbox">
                            <label>{{ $view_same['status'] }}</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Assigned To</label>
                        <div class="checkbox">
                            <label>{{ $employee }}</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Text and Remarks</label>
                        <div class="checkbox">
                            <label>{{ $view_same['text_remarks'] }}</label>
                        </div>
                    </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="first-name">Categories
                    </label>
                    <div class="col-md-6 col-xs-6 col-xs-12">
                        <a class="btn btn-success" id="show_cat" data-toggle="modal" data-target="#product_view">Select Categories</a>
                    </div>
                </div>

                <div class="form-group">
                <form method="post" action="{{ URL::to('rbsadmin/enquiry/'.$view_same['id'].'?view=ok') }}" class="form-horizontal form-label-left">
                    {{ FORM::token() }}
                <div class="form-group">
                    <label class="control-label col-md-3" for="first-name">Vendor
                    </label>
                    <div id="vendorsload">

                    </div>
                </div>


                    <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                            <a href="{{ URL::to('rbsadmin/enquiry') }}" class="btn btn-primary">Back</a>

                                <input type="hidden" name="_method" value="put" />
                                <button class="btn btn-success" id="enquiryedit" type="submit">Submit</button>
                        </div>
                    </div>
                </form>
                </div>

                <div class="modal fade product_view" id="product_view">
                    <div class="modal-dialog" style="width:90%;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title">Categories</h3>
                            </div>
                            <div class="modal-body">
                                <div class="row">

                                    <div class="form-group ul-align">
                                        @if(@$category)
                                            @foreach(@$category[0] as $val)
                                                <div class="accordion" id="accordion1" role="tablist" aria-multiselectable="true">
                                                    <div class="panel">
                                                        <a class="panel-heading" role="tab" id="headingOne1" data-toggle="collapse" data-parent="#accordion1" href="#collapse_{{ $val['id'] }}" aria-expanded="true" aria-controls="collapseOne">
                                                            <h4 class="panel-title"> {{ $val['cat_name'] }}</h4>
                                                        </a>
                                                        <div id="collapse_{{ $val['id'] }}" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                            <div class="panel-body">

                                                                @if(@$category[$val['id']])
                                                                    @foreach(@$category[$val['id']] as $subval)
                                                                        <div class="col-md-3">
                                                                            @if(@$category_select)
                                                                                <input type="checkbox" name="{{ 'catid['.$subval['id'].']' }}" class="flat" value="{{ $subval['id'] }}" @if(in_array($subval['id'], @$category_select)) checked="checked" @endif  />
                                                                            @else
                                                                                <input type="checkbox" name="{{ 'catid['.$subval['id'].']' }}" class="flat" value="{{ $subval['id'] }}"/>
                                                                            @endif


                                                                            {{ $subval['cat_name'] }}
                                                                        </div>
                                                                    @endforeach

                                                                @endif

                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            @endforeach
                                        @else
                                            {{ "Please Create Categories to Show here" }}
                                        @endif
                                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-11">
                                            <a href="#" data-dismiss="modal" id="category_confirm" class="btn btn-success">Submit</a>
                                        </div>
                                    </div>
                                    <div class="col-md-6">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ln_solid"></div>


                <div class="table-responsive">
                        <table class="table table-striped jambo_table bulk_action">
                            <thead>
                            <tr class="headings">
                                <th>Company Name</th>
                                <th>Contact Person</th>
                                <th>Phone / Mobile</th>
                                <th>Mail id</th>
                                <th>Status</th>
                                <th>Description</th>
                            </tr>
                            </thead>

                    @foreach(@$view_vendor as $val)

                    <tbody>
                    <tr class="odd-pointer">
                        <td>{{ $val['company_name'] }}</td>
                        <td>{{ $val['sm_contactperson'] }}</td>
                        <td><b>Ph:</b> {{ $val['sm_phone'] }} <br><b>Mob:</b> {{ $val['sm_mobile'] }}</td>
                        <td>{{ $val['sm_mailid'] }}</td>
                        <td colspan="2">
                        <form method="post" action="{{ URL::to('rbsadmin/enquiry/'.$val['id'].'/'.$view_same['id']) }}">
                        {{ FORM::token() }}
                            <select name="status_vendor" style="float: left">
                                <option value="0"> -Select- </option>
                                @foreach(@$stats as $status)
                                    <option @if(@$val['pivot']['status'] == $status) selected  @endif value="{{ $status }}">{{ $status }}</option>
                                @endforeach
                            </select>
                            &nbsp;&nbsp;
                            <span style="float: left;width: 300px;
    padding-left: 15px;" class="trigger_button" id="lable_{{ $val['id'] }}"  data-val = "{{ $val['id'] }}">{{ $val['pivot']['description'] ? $val['pivot']['description'] : "-" }}</span>
                            <span class="{{'desc_textplace'}}" id="{{ $val['id'] }}">
                                                    <textarea  style="height: 60px;" name="vendor_desc" >{{ $val['pivot']['description'] ? $val['pivot']['description'] :  "" }}</textarea>
                            </span>
                            <br>
                            <button  class="btn btn-success" style="float: right;" type="submit">Submit</button>

                        </form>
                        </td>
                    </tr>
                    </tbody>

                    @endforeach

                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $('.desc_textplace').hide();

        $('.trigger_button').click(function () {
            var as = $(this).attr('data-val');
            $('#' + as).show();
            $('#lable_' + as).hide();

            $('input').blur(function () {
                $('.desc_textplace').hide();
            });
        });


        var vendorselids = {!! json_encode(@$ven_select_edit) !!};


            $('#category_confirm').click(function () {
            var catids = {};
            var inc = 0;
            var values = $('input:checkbox:checked').map(function () {
                var obj = $(this).val();
                catids[inc] = obj;
                inc++;
            });
            var catidsJson = JSON.stringify(catids);

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })

            $.ajax({
                method: 'post',
                url: APP_URL + '/rbsadmin/enquiry/catfetch/ajax/category',
                data: 'catdata=' + catidsJson,
                async: true,
                success: function (response) {
                    var xyz = '';

                    var vendarrayay = [];
                    $.each(response, function (index, item) {
                        xyz += '<div class="col-md-3">';
                        xyz += '<div class="checkbox">';
                        xyz += '<label>';

                        if (jQuery.inArray(parseInt(index), vendorselids) !== -1) {
                            checkd = 'checked';
                        } else {
                            checkd = '';
                        }

                        vendarrayay.push({label: item, value: index});

                        xyz += '<input type="checkbox" ' + checkd + ' class="vendo"  name="vendor[' + index + ']" value=' + index + ' id=' + index + '> ' + item;
                        xyz += '</label>';
                        xyz += '</div>';
                        xyz += '</div>';
                    });


                    $('#vendorsload').html(xyz);

                    $('input.flat').iCheck({
                        checkboxClass: 'icheckbox_flat-green',
                        radioClass: 'iradio_flat-green'
                    });

                },
                error: function (data) {
                    alert(data + 'failed to process');
                }
            });
        });
    });
</script>
@endsection