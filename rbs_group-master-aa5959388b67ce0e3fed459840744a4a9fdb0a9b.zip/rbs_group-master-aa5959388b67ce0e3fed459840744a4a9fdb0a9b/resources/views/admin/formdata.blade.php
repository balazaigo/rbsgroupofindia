@extends('layouts.admin')

@section('content')
<div class="container">

    <form method="get" action="{{ URL::to('rbsadmin/form') }}">
    <div class="title_right">
        <div class="col-md-5 col-sm-5 col-xs-5 form-group pull-right top_search">

            <div class="input-group">
                <input type="text" name="search" value = "{{ $retain_search }}" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                      <button class="btn btn-default" type="submit">Go!</button>

                    </span>

            </div>
        </div>
    </div>
    </form>

    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">

            <div class="x_title">
                <h2>Vendor List</h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a href="{{ URL::to('rbsadmin/form/create') }}" class="plus-circle"><i class="fa fa-plus-circle"></i>Add Vendor</a></li>
                </ul>
                <div class="clearfix"></div>

            </div>
            <div class="row">


                <div class="col-md-12">

                    <div class="table-responsive">


                        <table id="mytable" class="table dataTable table-bordred table-striped">

                            <thead>

                            <th>S.No</th>
                            <th data-sort="company_name" class="sorting">Company Name</th>
                            <th data-sort="sm_contactperson" class="sorting">Sales and Marketing Contact Person</th>
                            <th data-sort="sm_phone" class="sorting">Phone</th>
                            <th data-sort="sm_mobile" class="sorting">Mobile</th>
                            <th data-sort="sm_mailid" class="sorting">Mail Id</th>
                           <th>View</th>
                            <th>Edit</th>

                            <th>Delete</th>
                            </thead>
                            <tbody>

                            @if(@$form_fields)
                            <?php $var = 1 ?>

                            @foreach($form_fields as $val)

                                <tr>

                                    <td>{{ $var+$page_quer }}</td>
                                    <td>{{ $val->company_name }}</td>
                                    <td>{{ $val->sm_contactperson }}</td>
                                    <td>{{ $val->sm_phone }}</td>
                                    <td>{{ $val->sm_mobile }}</td>
                                    <td>{{ $val->sm_mailid }}</td>
                                    <td>
                                        <form method="get" action="{{ URL::to('rbsadmin/form/'.$val->id) }}" data-placement="top" data-toggle="tooltip" title="Edit"> <button type="submit" class="vendor-form-view"><i class="fa fa-external-link"></i></button></form></td>

                                    <td>
                                        <a href="{{ URL::to('rbsadmin/form/'.$val->id.'/edit') }}" data-placement="top" data-toggle="tooltip" title="Edit"> <button class="vendor-form-edit" type="submit"><i class="fa fa-edit"></i></button></a></td>

                                    <td><form method="post" action="{{ URL::to('rbsadmin/form/'.$val->id) }}" data-placement="top" data-toggle="tooltip" title="Delete">
                                            {{ FORM::token() }}
                                            <input name="_method" type="hidden" value="DELETE">
                                            <button onsubmit="return confirm('are you sure?')" class="vendor-form-delete"><i class="fa fa-trash"></i></button></form></td>
                                </tr>
                                <?php $var++; ?>
                            @endforeach

                            @else
                                {{ "Please Create Vendor" }}
                            @endif

                            </tbody>
                        </table>
                        <div class="clearfix"></div>
                        {{ $form_fields->appends(\Input::except('page'))->render() }}


                    </div>
                </div>
            </div>
@endsection