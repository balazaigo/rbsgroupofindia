@extends('layouts.admin')

@section('content')
    <div class="x_panel">
        <div class="x_title">
            <h2>@if(@$enq_edit)<h2>{{ "Enquiry Edit" }}</h2>@else <h2>Enquiry Entry</h2>@endif</h2>

            <div class="clearfix"></div>

        </div>

        <form method="post" @if(@$enq_edit) action="{{ URL::to('rbsadmin/enquiry/'.$enq_edit['id']) }}" @else action="{{ URL::to('rbsadmin/enquiry') }}" @endif class="form-horizontal form-label-left">
            {{ FORM::token() }}
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">Enquiry Date<span class="required">*</span>
                </label>
                <div class="col-md-7">
                   <input type="text" id="datepicker" name="enq_date" class="form-control col-md-6" placeholder="Enquiry Date" @if(@$enq_edit) value="{{ \Carbon\Carbon::parse($enq_edit['enquiry_date'])->format('m/d/Y') }}" @else value="{{ old('enq_date') }}" @endif/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">RFQ NUMBER<span class="required">*</span>
                </label>
                <div class="col-md-7">
                    <input type="text" name="rfq_number" class="form-control col-md-6" placeholder="RFQ NUMBER" @if(@$enq_edit) value="{{ $enq_edit['rfq_number'] }}" @else value="{{ old('rfq_number') }}" @endif/>
                </div>
            </div>
            @if(Auth::user()->urole==1)
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">RBS OFFER NUMBER
                </label>
                <div class="col-md-7">
                    <input type="text" name="rbs_offer_number" class="form-control col-md-6" placeholder="RBS OFFER NUMBER" @if(@$enq_edit) value="{{ $enq_edit['rbs_offer_number'] }}" @else value="{{ old('rbs_offer_number') }}" @endif/>
                </div>
            </div>
            <div class="x_title">
            <h2>OFFER</h2> <div class="clearfix"></div>
           </div>
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">OFFER Value
                </label>
                <div class="col-md-7">
                    <input type="text" name="offer_value" class="form-control col-md-6" placeholder="OFFER VALUE" @if(@$enq_edit) value="{{ $enq_edit['offer_value'] }}"@else value="{{ old('offer_value') }}" @endif/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">Customer<span class="required">*</span>
                </label>
                <div class="col-md-7">
                    <select name="customer" class="form-control"><option value=""> Select Customer </option>
                        @foreach($customer as $val)
                            <option @if(@$enq_edit['customer'] == $val['customer_name']) selected @endif @if(@$val['customer_name'] == old('customer')) selected @endif value="{{ $val['customer_name'] ? $val['customer_name'] : old('customer') }}">{{ $val['customer_name'] }}</option>
                        @endforeach
                    </select>

                </div>
            </div>
            @endif
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">Description<span class="required">*</span>
                </label>
                <div class="col-md-7">
                    <textarea id="description" name="description" style="display:none;"></textarea>
                    <div id="summernote"></div>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">Status<span class="required">*</span>
                </label>
                <div class="col-md-6 col-xs-6 col-xs-12">
                    <select name="status" class="form-control"><option value=""> Select Option </option>
                        @foreach($stats as $val)
                        <option @if(@$enq_edit['status'] == $val) selected  @endif @if(@$val == old('status')) selected @endif value="{{ $val ? $val : old('status') }}">{{ $val }}</option>
                        @endforeach
                    </select>

                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">Assigned To<span class="required">*</span>
                </label>
                <div class="col-md-6 col-xs-6 col-xs-12">
                    <select name="emp_id" class="form-control">
                        <option value=""> Select Employee </option>
                        @foreach($emp as $val)
                        <option @if(@$enq_edit['emp_id'] == $val['id']) selected @endif @if(@$val['id'] == old('emp_id'))  selected @endif value="{{ $val['id'] ? $val['id'] : old('emp_id') }}">{{ $val['name'] }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">Notes and Remarks
                </label>
                <div class="col-md-7">
                    <textarea  style="width: 600px; height: 300px;" name="text_remarks" > @if(@$enq_edit) {{ $enq_edit['text_remarks'] ? $enq_edit['text_remarks'] : old('text_remarks') }} @else {{ old('text_remarks') }} @endif</textarea>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3" for="first-name">Categories
                </label>
                <div class="col-md-6 col-xs-6 col-xs-12">
                    <a class="btn btn-success" id="show_cat" data-toggle="modal" data-target="#product_view">Select Categories</a>
                </div>
            </div>

<div class="form-group">
                <label class="control-label col-md-3" for="first-name">Vendor
                </label>
                <div id="vendorsload">

                </div>
            </div>
            <!--<div class="form-group">
                <label class="control-label col-md-3">Vendor By Name</label>
                <div class="col-md-6 col-xs-6 col-xs-12">
                    <input id="tags_1" type="text" class="tags form-control"/>
                    <input id="tags_1_val" type="hidden"/>
                    <div id="suggestions-container"></div>
                    <input type="button" class="btn btn-primary nev" value="Submit"/>
                </div>
            </div>-->
            <div class="modal fade product_view" id="product_view">
                <div class="modal-dialog" style="width:90%;">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Categories</h3>
                            <label class="control-label col-md-3">Vendor By Name</label>
                            <div class="col-md-3">
                                <input id="vbyname" type="text" class="tags"/>

                                <div id="suggestions-container"></div>

                            </div>
                        </div>
                        <div class="modal-body">
                            <div class="row">

                                <div class="form-group ul-align">
                                    @if(@$category)
                                        @foreach(@$category[0] as $val)
                                            <div class="accordion" id="accordion1" role="tablist" aria-multiselectable="true">
                                                <div class="panel">
                                                    <a class="panel-heading" role="tab" id="headingOne1" data-toggle="collapse" data-parent="#accordion1" href="#collapse_{{ $val['id'] }}" aria-expanded="true" aria-controls="collapseOne">
                                                        <h4 class="panel-title"> {{ $val['cat_name'] }}</h4>
                                                    </a>
                                                    <div id="collapse_{{ $val['id'] }}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                        <div class="panel-body accordioncontent">

                                                            @if(@$category[$val['id']])
                                                                @foreach(@$category[$val['id']] as $subval)
                                                                    <div class="col-md-3">
                                                                        @if(@$category_select)
                                                                        <input type="checkbox" name="{{ 'catid['.$subval['id'].']' }}" class="flat" value="{{ $subval['id'] }}" @if(in_array($subval['id'], @$category_select)) checked="checked" @endif  />
                                                                        @else
                                                                            <input type="checkbox" name="{{ 'catid['.$subval['id'].']' }}" class="flat" value="{{ $subval['id'] }}"/>
                                                                        @endif


                                                                        <span class="high_search">{{ $subval['cat_name'] }}</span>
                                                                    </div>
                                                                @endforeach

                                                            @endif

                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        @endforeach
                                    @else
                                        {{ "Please Create Categories to Show here" }}
                                    @endif
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-11">
                                    <a href="#" data-dismiss="modal" id="category_confirm" class="btn btn-success">Submit</a>
                                </div>
                                </div>
                                <div class="col-md-6">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ln_solid"></div>
            <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <a href="{{ URL::to('rbsadmin/enquiry') }}" class="btn btn-primary">Back</a>
                    @if(@$enq_edit)
                        <input type="hidden" name="_method" value="put" />
                      <button class="btn btn-success" id="enquiryedit" type="submit">Submit</button>
                        @else
            <button class="btn btn-success" id="enquirycreate" type="submit">Submit</button>
                @endif
                </div>
            </div>


        </form>


    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            var vendorselids = {!! json_encode(@$ven_select_edit) !!};

            var enq = {!! json_encode(@$enq_edit['description']) !!}

            $('#category_confirm').click(function(){
                var catids = {};
                var inc = 0;
                var values = $('input:checkbox:checked').map(function(){
                    var obj = $(this).val();
                    catids[inc] = obj;
                    inc++;
                });
                var catidsJson = JSON.stringify(catids);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                })

                    $.ajax({
                    method : 'post',
                    url: APP_URL + '/rbsadmin/enquiry/catfetch/ajax/category',
                    data: 'catdata='+catidsJson,
                    async: true,
                    success:function(response){
                        var xyz = '';

                       var vendarrayay= [];
                        $.each(response, function(index, item) {
                            xyz += '<div class="col-md-3">';
                            xyz += '<div class="checkbox">';
                            xyz += '<label>';

                            if(jQuery.inArray(parseInt(index), vendorselids) !== -1){
                                checkd = 'checked';
                            }else{
                                checkd = '';
                            }

                            vendarrayay.push({label:item, value:index});

                            xyz += '<input type="checkbox" '+checkd+' class="vendo"  name="vendor['+index+']" value='+index+' id='+index+'>'+item;
                            xyz += '</label>';
                            xyz += '</div>';
                            xyz += '</div>';
                        });


                        $('#vendorsload').html(xyz);

                        $('input.flat').iCheck({
                            checkboxClass: 'icheckbox_flat-green',
                            radioClass: 'iradio_flat-green'
                        });

                    },
                    error:function(data){
                        alert(data+'failed to process');
                    }
                });
            });





            if(enq)
            {
                $('.Editor-editor').html(enq);
            }


            $('#enquirycreate,#enquiryedit').click(function () {
                var edits = $('.Editor-editor').html();
                $('#description').val(edits);
            });
            $('#category_confirm').click();


            $('#vbyname').keyup(function(data){
                $('.accordioncontent').removeHighlight();
                var searchTerm = $(this).val();
                $('.collapse').removeClass("in");
                if (searchTerm) {


                    $('.accordioncontent').highlight(searchTerm);
                    $('.highlight').closest('.collapse').addClass("in");
                }

            });

        });

    </script>

@endsection