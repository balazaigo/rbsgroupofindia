@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="page-title">
        <div class="title_left">
            <form method="get" action="{{ URL::to('rbsadmin/enquiry') }}">
                <div class="input-group">
                    <select name="status_dropdown">
                        <option value="">-Select-</option>
                        @foreach($stats as $val)
                            <option @if(@$select == $val) selected @endif value="{{ $val }}">{{ $val }}</option>
                        @endforeach
                    </select><button style="background: none; border:none; padding-left:10px;" class="btn btn-default" type="submit">Go!</button>
                </div>
        </div>

        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-5 form-group pull-right top_search">
                    <div class="input-group">
                        <input type="text" name="search" value = "{{ $retain_search }}" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                      <button class="btn btn-default" type="submit">Go!</button>

                    </span>

                    </div>
                </form>
            </div>
        </div>
        </div>
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">

                <div class="x_title">
                    <h2>Enquiry Management</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a href="{{ URL::to('rbsadmin/enquiry/create') }}" class="plus-circle"><i class="fa fa-plus-circle"></i>Create Enquiry</a></li>
                    </ul>
                    <div class="clearfix"></div>

                </div>



                    <div class="col-md-12">

                        <div class="table-responsive">


                            <table id="mytable" class="table dataTable table-bordred table-striped">

                                <thead>

                                @if(@$enq_view)
                                <th>S.No</th>
                                <th data-sort="enquiry_date" class="sorting">Date of Enquiry</th>
                                <th data-sort="rfq_number" class="sorting">RFQ Number</th>
                                <th data-sort="status" class="sorting">Status</th>
                                <th data-sort="emp" class="sorting">Assigned To</th>
                           @if(Auth::user()->urole==1)
                                <th data-sort="rbs_offer_number" class="sorting">Offer No</th>
                                <th data-sort="offer_value" class="sorting">Offer Value</th>

                                <th data-sort="customer" class="sorting">Customer</th>
                           @endif
                                <th>View</th>
                                @if(Auth::user()->urole==1)
                                <th>Edit</th>
                                <th>Delete</th>
                                @endif
                                </thead>
                                <tbody>
                                <?php $var = 1 ?>
                                @foreach($enq_view as $val)
                                    <tr>

                                        <td>{{ $var+$page_quer }}</td>
                                        <td>
                                           {{ date('d/m/Y', strtotime($val->enquiry_date)) }}
                                        </td>
                                        <td>{{ $val->rfq_number }}</td>
                                        <td><select name="status" >
                                                @foreach($stats as $vval)
                                                    <option @if(@$val->status == trim($vval)) selected @endif value="{{ trim($vval) }}">{{ trim($vval) }}</option>
                                                @endforeach
                                            </select></td>

                                        <td>{{ $val->employee->name }}</td>
                                        @if(Auth::user()->urole==1)
                                        <td>{{ $val->rbs_offer_number }}</td>
                                        <td>{{ $val->offer_value }}</td>
                                        <td>{{ $val->customer }}</td>
                                        @endif
                                        <td>
                                            <form method="get" action="{{ URL::to('rbsadmin/enquiry/'.$val->id) }}"> <button class="vendor-form-view" formtarget="_blank" type="submit"><i class="fa fa-external-link"></i></button></form>
                                        </td>
                                        @if(Auth::user()->urole==1)
                                        <td>
                                            <a target="_blank" href="{{ URL::to('rbsadmin/enquiry/'.$val->id.'/edit') }}" data-placement="top" data-toggle="tooltip" title="Edit"> <button class="vendor-form-edit" type="submit"><i class="fa fa-edit"></i></button></a></td>

                                        <td><form method="post" action="{{ URL::to('rbsadmin/enquiry/'.$val->id) }}" data-placement="top" data-toggle="tooltip" title="Delete">
                                                {{ FORM::token() }}
                                                <input name="_method" type="hidden" value="DELETE">
                                                <button onsubmit="return confirm('are you sure?')" class="vendor-form-delete"><i class="fa fa-trash"></i></button></form></td>
                                            @endif
                                    </tr>
                                    <?php $var++; ?>
                                @endforeach
                                </tbody>
                                @else
                                    <a href="{{ URL::to('rbsadmin/enquiry/create') }}">Please Create Enquiry</a>
                                @endif
                            </table>

                            <div class="clearfix"></div>
                            {{ $enq_view->appends(\Input::except('page'))->render() }}


                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection