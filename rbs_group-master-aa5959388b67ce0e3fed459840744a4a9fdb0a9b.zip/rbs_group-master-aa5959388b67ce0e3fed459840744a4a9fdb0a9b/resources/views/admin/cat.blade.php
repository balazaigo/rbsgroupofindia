@extends('layouts.admin')

@section('content')
<div class="container">
    <div class="page-title">
        <div class="title_left">
            <h4>Categories List</h4>
        </div>
    </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Categories</h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a href="{{ URL::to('rbsadmin/category/create') }}" class="plus-circle"><i class="fa fa-plus-circle"></i>Create Category</a></li>
                </ul>
                <div class="clearfix"></div>

            </div>
                <div class="tree_container container">
                    <ul class="cat_align">
                        @if(@$cat)
                        @foreach($cat[0] as $val)

                            <li class="hasSubmenu"><a  style="margin-left: 5px" href="{{ URL::to('rbsadmin/category/'.$val['id'].'/edit') }}">{{ $val['cat_name'] }}</a>
                                        <form method="post" class="ul-form" action="{{ URL::to('rbsadmin/category/'.$val['id']) }}">
                                            {{ FORM::token() }}
                                            <input name="_method" type="hidden" value="DELETE"/>
                                        <button class="fa fa-times"></button></form>

                            @if(@$cat[$val['id']])
                            <ul>
                                @foreach($cat[$val['id']] as $subval)
                                <li><a style="margin-left: 5px" href="{{ URL::to('rbsadmin/category/'.$subval['id'].'/edit') }}">{{ $subval['cat_name'] }}</a>


                                    <form method="post" action="{{ URL::to('rbsadmin/category/'.$subval['id']) }}">
                                        {{ FORM::token() }}
                                        <input name="_method" type="hidden" value="DELETE"/>
                                        <button class="fa fa-times" style="float:right; border:none; background:none;"></button></form>

                                </li>
                                @endforeach
                            </ul>
                                @endif
                        </li>
                        @endforeach
                    @else
                            <a href="{{ URL::to('rbsadmin/category/create') }}">Please Add Categories</a>
                    @endif
                    </ul>
                </div>
        </div>
@endsection