@extends('layouts.admin')

@section('content')
    <div class="x_panel">
        <div class="x_title">
            <h4>Status Settings</h4>
        </div>
        <div class="x_content">
            <form method="post" action="{{ URL::to('rbsadmin/status') }}">
                {{ FORM::token() }}
                <div class="form-group">
                    <label class="control-label col-md-3">Status</label>
                    <div class="col-md-7">
                        <textarea id="enq_status" class="col-lg-6" name="status">@foreach(@$status as $val){!! $val['status'] ? trim($val['status']) : "" !!}@endforeach</textarea>
                    </div>
                    <label class="control-label col-md-3">Vendor Status</label>
                    <div class="col-md-7">
                        <textarea id="enq_status" class="col-lg-6" name="status_vendor">@foreach(@$status as $vendor){{ $vendor['status_vendor'] ? $vendor['status_vendor'] : "" }}@endforeach</textarea>
                    </div>
                </div>

            <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <button class="btn btn-success" id="enquiryedit" type="submit">Submit</button>
                </div>
            </div>
            </form>
        </div>
    </div>
@endsection
