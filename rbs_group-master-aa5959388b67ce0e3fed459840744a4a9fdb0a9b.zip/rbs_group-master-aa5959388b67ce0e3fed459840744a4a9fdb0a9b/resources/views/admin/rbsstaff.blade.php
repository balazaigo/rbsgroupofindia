@extends('layouts.admin')

@section('content')



            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-5 form-group pull-right top_search">
<form method="get" action="{{ URL::to('rbsadmin/staff') }}">
                    <div class="input-group">
                        <input type="text" name="search" value = "{{ $retain_search }}" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                      <button class="btn btn-default" type="submit">Go!</button>

                    </span>

                    </div>
</form>
                </div>
            </div>



        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Staffs</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a href="{{ URL::to('rbsadmin/staff/create') }}" class="plus-circle"><i class="fa fa-plus-circle"></i>New Staff</a></li>
                    </ul>
                    <div class="clearfix"></div>

                </div>
                    <div class="row">


                        <div class="col-md-12">

                            <div class="table-responsive">


                                <table id="mytable" class="table dataTable table-bordred table-striped">

                                    <thead>

                                    <th>S.No</th>
                                    <th data-sort="name" class="sorting">First Name</th>
                                    <th data-sort="email" class="sorting">Email</th>
                                    <th>Edit</th>

                                    <th>Delete</th>
                                    </thead>
                                    <tbody>
                                    <?php $var = 1 ?>
                                    @foreach($user as $val)
                                    <tr>
                                        <td>{{ $var+$page_quer }}</td>
                                        <td>{{ $val->name }}</td>
                                        <td>{{ $val->email }}</td>

                                        <td>
                                            <a href="{{ URL::to('rbsadmin/staff/'.$val->id.'/edit') }}" data-placement="top" data-toggle="tooltip" title="Edit"> <button type="submit" class="staff-edit"><i class="fa fa-edit"></i></button></a></td>

                                        <td><form method="post" action="{{ URL::to('rbsadmin/staff/'.$val->id) }}" data-placement="top" data-toggle="tooltip" title="Delete">
                                                {{ FORM::token() }}
                                                <input name="_method" type="hidden" value="DELETE">
                                                <button class="staff-delete"><i class="fa fa-trash"></i></button></form></td>
                                        <?php $var++; ?>
                                    </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                                <div class="clearfix"></div>
                                {{ $user->appends(\Input::except('page'))->render() }}


            </div>
        </div>


                    <!-- /.modal-dialog -->

@endsection