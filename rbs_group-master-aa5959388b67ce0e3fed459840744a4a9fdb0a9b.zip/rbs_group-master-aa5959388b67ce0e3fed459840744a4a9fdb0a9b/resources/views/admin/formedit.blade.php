@extends('layouts.admin')

@section('content')

    <div class="x_panel">
        <div class="x_title">
            <h2>@if(@$form_edit){{ (@$form_edit['company_name']) }}<small>Sales Person Details</small>@else Company Details @endif</h2>

            <div class="clearfix"></div>
        </div>

        <div class="x_content">
            <br />


            <form method="post" @if(@$form_edit) action="{{ URL::to('rbsadmin/form/'.@$form_edit['id']) }}" @else action="{{ URL::to('rbsadmin/form') }}" @endif class="form-horizontal form-label-left">
                <div class="form-group">
                    <label class="control-label col-md-3" for="first-name">Company Name<span class="required">*</span>
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="company_name" required="required" value="{{ (@$form_edit['company_name']) ? $form_edit['company_name'] : old('company_name') }}" placeholder="Company Name"  class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                {{ FORM::token() }}
                <div class="x_title"><h4>Sales And Marketing</h4></div>
                <div class="clearfix"></div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="first-name">Contact Person<span class="required">*</span>
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="sm_contactperson" id="first-name2" required="required" value="{{ (@$form_edit['sm_contactperson']) ? $form_edit['sm_contactperson'] : old('sm_contactperson') }}" placeholder="Contact Person" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Phone<span class="required">*</span>
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="sm_phone" value="{{ (@$form_edit['sm_phone']) ? $form_edit['sm_phone'] : old('sm_phone') }}" placeholder="Phone"  required="required" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Mobile<span class="required">*</span>
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="sm_mobile" value="{{ (@$form_edit['sm_mobile']) ? $form_edit['sm_mobile'] : old('sm_mobile') }}" placeholder="Mobile" required="required" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">eMail<span class="required">*</span>
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="sm_mailid" value="{{ (@$form_edit['sm_mailid']) ? $form_edit['sm_mailid'] : old('sm_mailid') }}" placeholder="email" required="required" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>

                    <div class="x_title"><h4>Factory Contact</h4></div>
                    <div class="clearfix"></div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Contact Person
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="fc_contactperson" value="{{ (@$form_edit['fc_contactperson']) ? $form_edit['fc_contactperson'] : old('fc_contactperson') }}" placeholder="Contact Person" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Phone
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="fc_phone" value="{{ (@$form_edit['fc_phone']) ? $form_edit['fc_phone'] : old('fc_phone') }}" placeholder="phone" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Mobile
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="fc_mobile" value="{{ (@$form_edit['fc_mobile']) ? $form_edit['fc_mobile'] : old('fc_mobile') }}" placeholder="Mobile" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">eMail
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="fc_mailid" value="{{ (@$form_edit['fc_mailid']) ? $form_edit['fc_mailid'] : old('fc_mailid') }}" placeholder="eMail" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>

                    <div class="x_title"><h4>Quality Team</h4></div>
                    <div class="clearfix"></div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Contact Person
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="qt_contactperson" value="{{ (@$form_edit['qt_contactperson']) ? $form_edit['qt_contactperson'] : old('qt_contactperson') }}" placeholder="Contact Person" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Phone
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="qt_phone" value="{{ (@$form_edit['qt_phone']) ? $form_edit['qt_phone'] : old('qt_phone') }}" placeholder="phone" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Mobile
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="qt_mobile" value="{{ (@$form_edit['qt_mobile']) ? $form_edit['qt_mobile'] : old('qt_mobile') }}" placeholder="Mobile" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">eMail
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="qt_mailid" value="{{ (@$form_edit['qt_mailid']) ? $form_edit['qt_mailid'] : old('qt_mailid') }}" placeholder="eMail" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>

                <div class="x_title"><h4>Overall head - quality / operations</h4></div>
                <div class="clearfix"></div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Contact Person
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="ohqo_contactperson" value="{{ (@$form_edit['ohqo_contactperson']) ? $form_edit['ohqo_contactperson'] : old('ohqo_contactperson') }}" placeholder="Contact Person" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Phone
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="ohqo_phone" value="{{ (@$form_edit['ohqo_phone']) ? $form_edit['ohqo_phone'] : old('ohqo_phone') }}" placeholder="Phone" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Mobile
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="ohqo_mobile" value="{{ (@$form_edit['ohqo_mobile']) ? $form_edit['ohqo_mobile'] : old('ohqo_mobile') }}"  placeholder="Mobile" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">eMail
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="ohqo_mailid" value="{{ (@$form_edit['ohqo_mailid']) ? $form_edit['ohqo_mailid'] : old('ohqo_mailid') }}" placeholder="eMail" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div >
                    <div class="x_title"><h4>Accounts</h4></div>
                    <div class="clearfix"></div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Contact Person
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="ac_contactperson" value="{{ (@$form_edit['ac_contactperson']) ? $form_edit['ac_contactperson'] : old('ac_contactperson') }}" placeholder="Contact Person" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Phone
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="ac_phone" value="{{ (@$form_edit['ac_phone']) ? $form_edit['ac_phone'] : old('ac_phone') }}" placeholder="Phone" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Mobile
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="ac_mobile" value="{{ (@$form_edit['ac_mobile']) ? $form_edit['ac_mobile'] : old('ac_mobile') }}" placeholder="Mobile" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">eMail
                        </label>
                        <div class="col-md-7">
                            <input type="text" name="ac_mailid" value="{{ (@$form_edit['ac_mailid']) ? $form_edit['ac_mailid'] : old('ac_mailid') }}" placeholder="Email" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                </div>
                <div class="x_title"><h4>Delivery/Dispatch</h4></div>
                <div class="clearfix"></div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Contact Person
                    </label>
                    <div class="col-md-7">
                        <input type="text" name="dd_contactperson" value="{{ (@$form_edit['dd_contactperson']) ? $form_edit['dd_contactperson'] : old('dd_contactperson') }}" placeholder="Contact Person" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Phone
                    </label>
                    <div class="col-md-7">
                        <input type="text"  name="dd_phone" value="{{ (@$form_edit['dd_phone']) ? $form_edit['dd_phone'] : old('dd_phone') }}" placeholder="Phone" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Mobile
                    </label>
                    <div class="col-md-7">
                        <input type="text"  name="dd_mobile" value="{{ (@$form_edit['dd_mobile']) ? $form_edit['dd_mobile'] : old('dd_mobile') }}" placeholder="Mobile" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">eMail
                    </label>
                    <div class="col-md-7">
                        <input type="text"  name="dd_mailid" value="{{ (@$form_edit['dd_mailid']) ? $form_edit['dd_mailid'] : old('dd_mailid') }}" placeholder="Email" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                    <div class="x_title"><h4>Banking</h4></div>
                    <div class="clearfix"></div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">Bank Details With IFSC Code
                        </label>
                        <div class="col-md-7">
                            <input type="text"  name="bank_details" value="{{ (@$form_edit['bank_details']) ? $form_edit['bank_details'] : old('bank_details') }}" placeholder="Bank Details" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3" for="last-name">GSTIN<span class="required">*</span>
                        </label>
                        <div class="col-md-7">
                            <input type="text"  name="gstin" value="{{ (@$form_edit['gstin']) ? $form_edit['gstin'] : old('gstin') }}" placeholder="GSTIN" required="required" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>

                <div class="x_title"><h4>About their Clients</h4></div>
                <div class="clearfix"></div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Brief about Company
                    </label>
                    <div class="col-md-7">
                        <input type="text"  name="overall_capability" value="{{ (@$form_edit['overall_capability']) ? $form_edit['overall_capability'] : old('overall_capability') }}" placeholder="brief about company" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Reference Clients Domestic / International
                    </label>
                    <div class="col-md-7">
                        <input type="text"  name="referenceclients" value="{{ (@$form_edit['referenceclients']) ? $form_edit['referenceclients'] : old('referenceclients') }}" placeholder="reference clients" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Credit Terms
                    </label>
                    <div class="col-md-7">
                        <input type="text"  name="creditterms" value="{{ (@$form_edit['creditterms']) ? $form_edit['creditterms'] : old('creditterms') }}" placeholder="Credit Terms" class="form-control col-md-7 col-xs-12">
                    </div>
                </div>
@if(!@$form_edit)
                <div class="form-group">
                    <label class="control-label col-md-3" for="last-name">Manufacturer<span class="required">*</span>
                    </label>
                    <div class="radio">
                        <label>
                            <input type="radio" id="man_1" name="manufacture_dealer" value="1" > Yes
                        </label>
                        <label class="man_2">
                            <input type="radio" id="man_2" name="manufacture_dealer" value="2"> No
                        </label>
                    </div>
                </div>

                <div class="form-group" id="form_will">
                    <label class="control-label col-md-3" for="last-name">Will you Supply Directly to RBS Group?
                    </label>
                    <div class="radio">
                        <label>
                            <input type="radio" name="supply_s" id="suppl_1" value="1"> Yes
                        </label>
                        <label>
                            <input type="radio" name="supply_s" id="suppl_2" value="2"> No
                        </label>
                    </div>
                </div>

                <div class="form-group" id="form_supply">
                    <label class="control-label col-md-3" for="last-name">Supply Through Dealer
                    </label>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="supply_directly" value="1">
                        </label>
                    </div>
                </div>
                <div class="form-group" id="provide_dealer">
                    <label class="control-label col-md-3" for="last-name">Provide Dealer Contact Details with mail id and Mobile Number<span class="required">*</span>
                    </label>
                    <div class="col-md-7">
                    <textarea class="resizable_textarea form-control" name="provide_dealer" placeholder="Dealer Details here"></textarea>
                    </div>
                </div>
                @endif
                <div class="form-group ul-align">
                    <label class="control-label col-md-3">Categories</label>
                    <div class="col-md-7">
                            <a class="btn btn-success" id="show_cat" data-toggle="modal" data-target="#product_view">Select Categories</a>
                        </div>
                </div>


                </div>

        <div class="modal fade product_view" id="product_view">
            <div class="modal-dialog" style="width:90%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">Categories</h3>
                    </div>
                    <div class="modal-body">
                        <div class="row">

                            <div class="form-group ul-align">
                                @if(@$category)
                                @foreach(@$category[0] as $val)



                                    <div class="accordion" id="accordion1" role="tablist" aria-multiselectable="true">
                                        <div class="panel">
                                            <a class="panel-heading" role="tab" id="headingOne1" data-toggle="collapse" data-parent="#accordion1" href="#collapse_{{ $val['id'] }}" aria-expanded="true" aria-controls="collapseOne">
                                                <h4 class="panel-title"> {{ $val['cat_name'] }}</h4>
                                            </a>
                                            <div id="collapse_{{ $val['id'] }}" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                <div class="panel-body">

                                                    @if(@$category[$val['id']])
                                                        @foreach(@$category[$val['id']] as $subval)
                                                            <div class="col-md-3">
                                                                                                                                @if(@$cat_selected)
                                                                    <input type="checkbox" name="{{ 'catid['.$subval['id'].']' }}" value="{{ $subval['id'] }}" @if(in_array($subval['id'], $cat_selected)) checked="checked" @endif  />
@else
                                                                    <input type="checkbox" name="{{ 'catid['.$subval['id'].']' }}" value="{{ $subval['id'] }}"  />
                                                                    @endif
                                                                {{ $subval['cat_name'] }}
                                                            </div>
                                                        @endforeach

                                                    @endif

                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                @endforeach
                                @else
                                    {{ "Please Create Categories  to show here." }}
                                @endif
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-11">
                                    <a href="#" data-dismiss="modal" id="category_confirm" class="btn btn-success">Submit</a>
                                </div>
                            </div>
                            <div class="col-md-6">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <div class="form-group">
                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                        <a href="{{ URL::to('rbsadmin/form') }}" class="btn btn-primary" type="reset">Back</a>
                        @if(@$form_edit)

                            <input type="hidden" name="_method" value="put" />
                            <button type="submit" class="btn btn-success">Submit</button>

                        @else
                            <button type="submit" class="btn btn-success">Submit</button>
                        @endif
                    </div>
                </div>

            </form>


        </div>

@endsection