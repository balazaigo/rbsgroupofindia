<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>ADMIN PANEL</title>

    <!-- Bootstrap -->
{{ HTML::style('assets/vendors/bootstrap/dist/css/bootstrap.min.css') }}

<!-- Font Awesome -->
{{HTML::style('assets/vendors/font-awesome/css/font-awesome.min.css')}}

<!-- NProgress -->
{{HTML::style('assets/vendors/nprogress/nprogress.css')}}

<!-- icheck -->
{{HTML::style('assets/vendors/icheck/skins/flat/green.css')}}

<!-- bootstrap-progressbar -->
{{HTML::style('assets/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css')}}

<!-- JQVMap -->
{{HTML::style('assets/vendors/jqvmap/dist/jqvmap.min.css')}}

<!-- bootstrap-daterangepicker -->
{{HTML::style('assets/vendors/bootstrap-daterangepicker/daterangepicker.css')}}

{{HTML::style('assets/vendors/bootstrap-ds/dataTables.bootstrap.min.css')}}

{{HTML::style('assets/tree/css/tree.css')}}

<!-- Custom Theme Style -->
    {{HTML::style('assets/build/css/custom.min.css')}}

    {{HTML::style('assets/editor/editor.css')}}

    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
    <script type="text/javascript">
        var APP_URL = {!! json_encode(url('/')) !!};
    </script>
    <!-- jQuery -->
    {{HTML::script('assets/vendors/jquery/dist/jquery.min.js')}}
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="{{ URL::to('rbsadmin') }}" class="site_title"><i class="fa fa-paw"></i> <span>RBS PANEL</span></a>
                </div>

                <div class="clearfix"></div>

                <!-- menu profile quick info -->
                <div class="profile clearfix">
                    <div class="profile_pic">
                        <img src="{{ asset('images/logo.jpg') }}" alt="..." class="img-circle profile_img">
                    </div>
                    <div class="profile_info">
                        <span>Welcome,</span>
                        <h2>{{  Auth::user()->name }}</h2>
                    </div>
                </div>
                <!-- /menu profile quick info -->

                <br />

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">
                        <ul class="nav side-menu">
                            <li><a href="{{ URL::to('rbsadmin') }}"><i class="fa fa-home"></i> Dashboard </a>
                            </li>

                            @if(\Auth::user()->urole==1)
                            <li><a href="#"><i class="fa fa-group"></i> Staffs <span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="{{ URL::to('rbsadmin/staff') }}">Staffs Listing</a></li>
                                    <li><a href="{{ URL::to('rbsadmin/staff/create') }}">Add Staffs</a></li>
                                </ul>
                            </li>
                            @endif

                            <li><a href="#"><i class="fa fa-tags"></i> Category <span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="{{ URL::to('rbsadmin/category') }}">Categories</a></li>
                                    <li><a href="{{ URL::to('rbsadmin/category/create') }}">Add Category</a></li>
                                </ul>
                            </li>
                            <li><a href="#"><i class="fa fa-globe"></i> Vendor <span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="{{ URL::to('rbsadmin/form') }}">Vendors List</a></li>
                                    <li><a href="{{ URL::to('rbsadmin/form/create') }}">Add New Vendor</a></li>
                                </ul>
                            </li>
                            <li><a href="#"><i class="fa fa-question"></i>Enquiry<span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="{{ URL::to('rbsadmin/enquiry') }}">Enqueries List</a></li>
                                    <li><a href="{{ URL::to('rbsadmin/enquiry/create') }}">New Enquiry</a></li>
                                </ul>
                            </li>


                            <li><a href="#"><i class="fa fa-reorder"></i>PO Management<span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="{{ URL::to('rbsadmin/purchase') }}">PO List</a></li>
                                    <li><a href="{{ URL::to('rbsadmin/purchase/create') }}">New PO</a></li>
                                </ul>
                            </li>

                            <li><a href="#"><i class="fa fa-tachometer"></i>Status<span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="{{ URL::to('rbsadmin/status') }}">Status List</a></li>
                                </ul>
                            </li>
                            @if(\Auth::user()->urole==1)
                            <li><a href="#"><i class="fa fa-male"></i>Customer<span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="{{ URL::to('rbsadmin/customer') }}">RBS Customers</a></li>
                                    <li><a href="{{ URL::to('rbsadmin/customer/create') }}">New Customer</a></li>
                                </ul>
                            </li>
                            @endif
                        </ul>
                    </div>

                </div>
                <!-- /sidebar menu -->

                <!-- /menu footer buttons -->
                <div class="sidebar-footer hidden-small">
                    <a data-toggle="tooltip" data-placement="top" title="Settings">
                        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                        <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="Lock">
                        <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="Logout" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                    </a>
                </div>
                <!-- /menu footer buttons -->
            </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <nav>
                    <div class="nav toggle">
                        <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                    </div>

                    <ul class="nav navbar-nav navbar-right">
                        <li class="">
                            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                <img src="{{ asset('images/logo.jpg') }}" alt="">{{  Auth::user()->name }}
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu pull-right">
                                <li><a href="{{ URL::to('rbsadmin/profile') }}"> Profile</a></li>
                                <li>
                                    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="fa fa-sign-out pull-right"></i> Log Out</a></li>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            </ul>
                        </li>

                        <li role="presentation" class="dropdown">
                            <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-envelope-o"></i>
                                <span class="badge bg-green">6</span>
                            </a>
                            <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                                    </a>
                                </li>
                                <li>
                                    <div class="text-center">
                                        <a>
                                            <strong>See All Alerts</strong>
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">

            <ol class="breadcrumb">
                @php
                    $getbc =  \BREAD::getbc()
                @endphp
                @foreach($getbc as $lable => $link)
                    <li class="breadcrumb-item @if(end($getbc) == $link) active @endif" ><a @if(end($getbc) != $link) href="{{ URL::to($link) }}" @endif >{{ $lable }}</a></li>
                @endforeach
                <!-- <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Library</a></li>
                <li class="breadcrumb-item active">Data</li> -->
            </ol>

            @if ($errors->any())
                <div class="alert alert-danger alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @if(Session::has('name_success'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Profile Updated Successfully!</p></strong>
                </div>
            @endif

            @if(Session::has('success_delete_category'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Deleted!</p></strong>
                </div>
            @endif
            @if(Session::has('success_updated_user'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>User Details Updated Successfully!</p></strong>
                </div>
            @endif
            @if(Session::has('deleted_successfully'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>User Details Deleted Successfully!</p></strong>
                </div>
            @endif
            @if(Session::has('success_new_user'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>New User Has been Enrolled Successfully</p></strong>
                </div>
            @endif
            @if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible fade in" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                        </button>
                        <strong><p>Password Updated Successfully!</p></strong>
                    </div>
            @endif
            @if(Session::has('success_new_category'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Category Created Succcessfully</p></strong>
                </div>
            @endif
            @if(Session::has('success_edit_category'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Category Name Edited Succcessfully</p></strong>
                </div>
            @endif
            @if(Session::has('company_form_created'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Company Profile Created</p></strong>
                </div>
            @endif

            @if(Session::has('company_form_updated'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Company Profile Updated</p></strong>
                </div>
            @endif

            @if(Session::has('delete_form_success'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Company Profile Deleted</p></strong>
                </div>
            @endif

            @if(Session::has('enquiry_created'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Your Enquiry Has been Registered Successfully</p></strong>
                </div>
            @endif

            @if(Session::has('enquiry_updated'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Changes in Enquiry Recorded Successfully</p></strong>
                </div>
            @endif
            @if(Session::has('deleted_enquiry_successfully'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Deleted Enquiry Successfully</p></strong>
                </div>
            @endif
            @if(Session::has('customer_created'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>New Customer added Successfully</p></strong>
                </div>
            @endif
            @if(Session::has('customer_updated'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Customer Updated Successfully</p></strong>
                </div>
            @endif
            @if(Session::has('customer_deleted'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Customer Deleted Successfully</p></strong>
                </div>
            @endif
            @if(Session::has('not_admin'))
                <div class="alert alert-danger alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Access Denied For Staff</p></strong>
                </div>
            @endif
            @if(Session::has('purchase_created'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Your Purchase Order Has been successfully registered</p></strong>
                </div>
            @endif
            @if(Session::has('purchase_updated'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Your Purchase Order Has been successfully Updated</p></strong>
                </div>
            @endif
            @if(Session::has('deleted_purchase_successfully'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Your Purchase Order Has been successfully Deleted</p></strong>
                </div>
            @endif
            @if(Session::has('status_update'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Status Updated Successfully</p></strong>
                </div>
            @endif
            @if(Session::has('stats_dup'))
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong><p>Vendor Details altered Successfully</p></strong>
                </div>
            @endif
            @yield('content')
        </div>
        <!-- /page content -->

    </div>
</div>

<!-- Bootstrap -->
{{HTML::script('assets/vendors/bootstrap/dist/js/bootstrap.min.js')}}
<!-- FastClick -->
{{HTML::script('assets/vendors/fastclick/lib/fastclick.js')}}
<!-- NProgress -->
{{HTML::script('assets/vendors/nprogress/nprogress.js')}}
<!-- Chart.js -->
{{HTML::script('assets/vendors/chartdotjs/dist/chart.min.js')}}
<!-- gauge.js -->
{{HTML::script('assets/vendors/gaugedotjs/dist/gauge.min.js')}}
<!-- bootstrap-progressbar -->
{{HTML::script('assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js')}}
<!-- icheck -->
{{HTML::script('assets/vendors/icheck/icheck.min.js')}}
<!-- Skycons -->
{{HTML::script('assets/vendors/skycons/skycons.js')}}
<!-- Flot -->
{{HTML::script('assets/vendors/fflot/jquery.flot.js')}}

{{HTML::script('assets/vendors/fflot/jquery.flot.pie.js')}}

{{HTML::script('assets/vendors/fflot/jquery.flot.time.js')}}

{{HTML::script('assets/vendors/fflot/jquery.flot.stack.js')}}

{{HTML::script('assets/vendors/fflot/jquery.flot.resize.js')}}

<!-- Flot plugins -->
{{HTML::script('assets/vendors/flot.orderbars/js/jquery.flot.orderBars.js')}}

{{HTML::script('assets/vendors/flot-spline/js/jquery.flot.spline.min.js')}}

{{HTML::script('assets/vendors/flot.curvedlines/curvedLines.js')}}

<!-- DateJS -->
{{HTML::script('assets/vendors/datejjs/build/date.js')}}

<!-- JQVMap -->
{{HTML::script('assets/vendors/jqvmap/dist/jquery.vmap.js')}}

{{HTML::script('assets/vendors/jqvmap/dist/maps/jquery.vmap.world.js')}}

{{HTML::script('assets/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js')}}

<!-- bootstrap-daterangepicker -->
{{HTML::script('assets/vendors/moment/min/moment.min.js')}}

{{HTML::script('assets/vendors/bootstrap-daterangepicker/daterangepicker.js')}}


<!-- Custom Theme Scripts -->
{{HTML::script('assets/build/js/custom.min.js')}}

{{ HTML::script('assets/tree/MultiNestedList.js') }}

{{ HTML::script('assets/highlight.js') }}

{{ HTML::script('assets/editor/editor.js') }}

<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script>
        $("#form_will").hide();
        $("#form_supply").hide();
        $("#provide_dealer").hide();
        $("#man_1").click(function() {
            $("#form_will").show();
            $("#suppl_1").prop('checked',false);
            $("#suppl_2").prop('checked',false);
            $("#form_supply").hide();
            $("#provide_dealer").hide();
        });
        $("#man_2").click(function(){
            $("#form_will").hide();
            $("#form_supply").hide();
            $("#provide_dealer").hide();
        });
        $("#suppl_2").click(function () {
            $("#form_supply").show();
            $("#provide_dealer").show();
        });
        $("#suppl_1").click(function(){
            $("#form_supply").hide();
            $("#provide_dealer").hide();
        });
        $( "#datepicker" ).datepicker();
        $( "#po_received" ).datepicker();
        $( "#po_delivery" ).datepicker();

        $( "#summernote" ).Editor();

            $('#mytable th').on('click', function () {
                if($(this).attr("data-sort")){

                    clicked = $(this).html();

                    $( "#mytable th" ).each(function( index ) {
                        if($(this).attr("data-sort") && (clicked != $(this).html()) ) {
                            $(this).removeClass('sorting_asc');
                            $(this).removeClass('sorting_desc');
                            $(this).addClass('sorting');
                        }
                    });

                    var sortby = '';

                    if($(this).hasClass("sorting")){
                        sortby = 'asc';
                        $(this).removeClass('sorting');
                        $(this).addClass('sorting_asc');
                    }else if($(this).hasClass("sorting_asc")){
                        sortby = 'desc';
                        $(this).removeClass('sorting_asc');
                        $(this).addClass('sorting_desc');
                    }else{
                        sortby = 'asc';
                        $(this).removeClass('sorting_desc');
                        $(this).addClass('sorting_asc');
                    }


                    window.location = "{{ url()->current() }}?search={{ app('request')->input('search') }}&field=" + $(this).attr("data-sort") + "&sort=" + sortby;

                }
            });

        function dosorting(field, sort){
            $("[data-sort=" + field + "]").removeClass('sorting');
            $("[data-sort=" + field + "]").addClass('sorting_'+ sort);
        }

        @if(app('request')->input('field') && app('request')->input('sort'))
            dosorting('{{ app('request')->input('field') }}','{{ app('request')->input('sort') }}');
    @endif


</script>

</body>
</html>