<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, maximum-scale=1">
    <title>RBS GROUP INDIA &#8211; We Build Structures &amp; Relationships to Last</title>
    <link rel="icon" href="http://rbsgroupindia.com/favicon.ico" type="image/ico">
    <link href="http://rbsgroupindia.com/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="http://rbsgroupindia.com/js/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
    <link href="http://rbsgroupindia.com/css/color.css" rel="stylesheet" type="text/css">
    <link href="http://rbsgroupindia.com/css/style.css" rel="stylesheet" type="text/css">
    <link href="http://rbsgroupindia.com/css/font-awesome.css" rel="stylesheet" type="text/css">
    <link href="http://rbsgroupindia.com/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://rbsgroupindia.com/css/animate.css" rel="stylesheet" type="text/css">
    <link href="http://rbsgroupindia.com/css/imageCaption.css" rel="stylesheet" type="text/css">
    <!-- Custom CSS -->
    <link href="http://rbsgroupindia.com/css/full-slider.css" rel="stylesheet">
    {{HTML::style('assets/tree/css/tree.css')}}

<!-- Owl Carousel Assets -->
    <link href="http://rbsgroupindia.com/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="http://rbsgroupindia.com/owl-carousel/owl.theme.css" rel="stylesheet">
    <!-- start-smoth-scrolling -->

    <!--[if lt IE 9]>
    <script src="http://rbsgroupindia.com/js/respond-1.1.0.min.js"></script>
    <script src="http://rbsgroupindia.com/js/html5shiv.js"></script>
    <script src="http://rbsgroupindia.com/js/html5element.js"></script>
    <![endif]-->
    <script>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-79999916-1', 'auto');
        ga('send', 'pageview');
    </script>
    <style>
        .bold {
            font-weight: 600 !important;
        }

        .bold2 {
            font-weight: 600 !important;
        }

        .clients img {
            margin: 6px auto !important;
        }
    </style>
</head>

<body>

<!--Header_section-->
<header id="header_wrapper" class="header active border">
    <div class="container">
        <div class="header_box">
            <div class="logo">
                <a href="http://rbsgroupindia.com/index.html"><img class="img-responsive" src="http://rbsgroupindia.com/images/logo-3.jpg"  alt="logo"></a>
            </div>
            <nav class="navbar navbar-inverse" role="navigation">
                <div class="navbar-header">
                    <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                </div>
                <div id="main-nav" class="collapse navbar-collapse navStyle">
                    <ul class="nav navbar-nav" id="mainNav">
                        <li><a href="http://rbsgroupindia.com/#" class="scroll-link hidden-xs">Home</a>
                            <a href="http://rbsgroupindia.com/#" class="visible-xs" data-toggle="collapse" data-target=".navbar-collapse">Home</a>
                        </li>
                        <li><a href="http://rbsgroupindia.com/#about" class="scroll-link hidden-xs">About Us</a>
                            <a href="http://rbsgroupindia.com/#about" class="visible-xs" data-toggle="collapse" data-target=".navbar-collapse">About Us</a>
                        </li>
                        <li><a href="http://rbsgroupindia.com/#procuremnet" class="scroll-link hidden-xs">Procurement</a>
                            <a href="http://rbsgroupindia.com/#procuremnet" class="visible-xs" data-toggle="collapse" data-target=".navbar-collapse">Procurement</a>
                        </li>
                        <li><a href="http://rbsgroupindia.com/#industry" class="scroll-link hidden-xs">Industry</a>
                            <a href="http://rbsgroupindia.com/#industry" class="visible-xs" data-toggle="collapse" data-target=".navbar-collapse">Industry</a>
                        </li>
                        <li><a href="http://rbsgroupindia.com/#products" class="scroll-link hidden-xs">Products</a>
                            <a href="http://rbsgroupindia.com/#products" class="visible-xs" data-toggle="collapse" data-target=".navbar-collapse">Products</a>
                        </li>
                        <!--<li><a href="http://rbsgroupindia.com/#capability" class="scroll-link hidden-xs">Capability</a>
                            <a href="http://rbsgroupindia.com/#capability" class="visible-xs" data-toggle="collapse" data-target=".navbar-collapse">Capability</a>
                        </li>-->
                        <li><a href="http://rbsgroupindia.com/#contact" class="scroll-link hidden-xs">Contact Us</a>
                            <a href="http://rbsgroupindia.com/#contact" class="visible-xs" data-toggle="collapse" data-target=".navbar-collapse">Contact Us</a>
                        </li>
                        <li class="active"><a href="#accreditation" class="scroll-link hidden-xs">Accreditation</a><a href="#accreditation" class="visible-xs" data-toggle="collapse" data-target=".navbar-collapse">Accreditation</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</header>

<!--about-->
<section id="accreditation" style="padding-top: 6%;" class="greybg">
    <div class="container">
        <h2 class="animated bounceIn wow delay-02s"><u>A</u>ccreditation Form</h2>
        @if ($errors->any())
            <div class="alert alert-danger alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if(Session::has('forminserted'))
            <div class="alert alert-success alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
                <strong><p>Created Vendor Successfully</p></strong>
            </div>
        @endif
        <div class="row">
            {{ FORM::open(['action'=>'FormController@store', 'method' => 'post']) }}

            <div class="form-group">
                {{ FORM::label('cn_companyname', 'Company Name') }}
                <br>
            <div class="col-md-6">
                {{ FORM::text('company_name', '',['class' => 'form-control', 'placeholder' => 'Company Name' ]) }}
            </div>
            </div>
            <br><br>
            <div class="form-group">
                {{ FORM::label('gstin', 'GSTIN') }}
                <br>
                <div class="col-sm-6">
                    <div class="form-group">
                        {{--required removed : 30-Aug-2017--}}
                        {{ FORM::text('gstin', '',['class' => 'form-control','placeholder' => 'GSTIN' ]) }}
                    </div>
                </div>
            </div><br><br>
            <div class="form-group">
                {{ FORM::label('sales_marketing','Sales & Marketing') }}
                <br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('sm_contactperson','',['class' => 'form-control', 'placeholder' => 'Contact Person' ]) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {{ FORM::text('sm_phone','',['class' => 'form-control','placeholder'=>'PHONE']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {{ FORM::text('sm_mobile','',['class' => 'form-control','placeholder'=>'Mobile']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {{ FORM::text('sm_email','',['class' => 'form-control','placeholder'=>'E-Mail']) }}
                    </div>
                </div>
            </div>

            <div class="form-group" hidden>
                {{ FORM::label('factorycont', 'Factory Contact') }}
               <br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('fc_contactperson','',['class'=>'form-control', 'placeholder' => 'Contact Person' ]) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('fc_phone','',['class' => 'form-control','placeholder'=>'PHONE']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {{ FORM::text('fc_mobile','',['class' => 'form-control','placeholder'=>'Mobile']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {{ FORM::text('fc_email','',['class' => 'form-control','placeholder'=>'E-Mail']) }}
                    </div>
                </div>
                    </div>
            <div class="form-group hidden">
                {{ FORM::label('qt_qualityteam', 'Quality Team') }}
                <br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('qt_contactperson','',['class'=>'form-control', 'placeholder' => 'Contact Person' ]) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {{ FORM::text('qt_phone','',['class' => 'form-control','placeholder'=>'PHONE']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('qt_mobile','',['class' => 'form-control','placeholder'=>'Mobile']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('qt_email','',['class' => 'form-control','placeholder'=>'E-Mail']) }}
                    </div>
                </div>
            </div><br>

            <div class="form-group" hidden>
                {{ FORM::label('ohqo_overallhead', 'Overall head - Quality / operations') }}
                <br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('ohqo_contactperson','',['class'=>'form-control', 'placeholder' => 'Contact Person' ]) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('ohqo_phone','',['class' => 'form-control','placeholder'=>'PHONE']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('ohqo_mobile','',['class' => 'form-control','placeholder'=>'Mobile']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('ohqo_email','',['class' => 'form-control','placeholder'=>'E-Mail']) }}
                    </div>
                </div>

            </div>
            <br>

            <div class="form-group hidden">
                {{ FORM::label('accounts', 'Accounts') }}
                <br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('ac_contactperson','',['class'=>'form-control', 'placeholder' => 'Contact Person' ]) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('ac_phone','',['class' => 'form-control','placeholder'=>'PHONE']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">

                {{ FORM::text('ac_mobile','',['class' => 'form-control','placeholder'=>'Mobile']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {{ FORM::text('ac_email','',['class' => 'form-control','placeholder'=>'E-Mail']) }}
                    </div>
                </div>
            </div>
            <br>

            <div class="form-group">
                {{ FORM::label('deliver', 'Deliver/Dispatch*') }}
                <br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('dd_contactperson','',['class'=>'form-control', 'placeholder' => 'Contact Person' ]) }}
                    </div>
                    </div>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('dd_phone','',['class' => 'form-control','placeholder'=>'PHONE']) }}
                    </div>
                    </div>
                <div class="col-sm-6">
                    <div class="form-group">
                    {{ FORM::text('dd_mobile','',['class' => 'form-control','placeholder'=>'Mobile']) }}
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                    {{ FORM::text('dd_email','',['class' => 'form-control','placeholder'=>'E-Mail']) }}
                    </div>
                </div>
            </div>
            <br>

            <div class="form-group hidden">
                {{ FORM::label('bankdetails', 'Bank Details With Ifsc Code') }}
            <br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('bank_details', '',['class' => 'form-control','placeholder'=>'Bank Details']) }}
                    </div>
                </div>
                <br>
            </div>

<br>
            <div class="form-group">
                {{ FORM::label('overallcapability', 'Brief About Company') }}
<br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::textarea('overallcapability', '', ['class'=>'form-control','placeholder'=>'Brief About Company','size' => '5x5']) }}
                    </div>
                </div>
            </div>
            <br><br><br><br><br><br>
            <div class="form-group">
                {{ FORM::label('ref', 'Reference Clients Domestic/International') }}
        <br>
                <div class="col-sm-6">
                    <div class="form-group">
                {{ FORM::text('reference', '',['class' => 'form-control','placeholder'=>'Clients']) }}
                    </div>
                </div>
            </div>
<br><br>
            <div class="form-group hidden">
                <div>
                    {{ FORM::label('credit', 'Credit Terms') }}
                    <br>
                    <div class="col-sm-6">
                        <div class="form-group">
                    {{ FORM::text('creditterms', '',['class' => 'form-control','placeholder'=>'Credit Terms', 'old' => 'creditterms']) }}
                        </div>
                    </div>
                        </div>
            </div>
<br><br>
            <div class="form-group">
                {{ FORM::label('manufacture_dealer_check', 'Manufacturer') }}
                {{ FORM::radio('manufacture_dealer','1','',['id'=>'manu_yes']) }}

                {{ FORM::label('manufacture_dealer_check', 'Dealer') }}
                {{ FORM::radio('manufacture_dealer','2','',['id'=>'manu_no']) }}
            </div>
            <div class="form-group" id="supply_rbs_group">
                <div>
                    Will you Supply Directly to RBS Group?
                </div>

                {{ FORM::label('supply', 'Yes') }}
                {{ FORM::radio('supply_s','1','',['id'=>'supp_s']) }}
                {{ FORM::label('supply', 'No') }}
                {{ FORM::radio('supply_s','2','',['id'=>'supp_no']) }}


            </div>

            <div class="form-group" id="supply_through_dealer">
                {{ FORM::label('supply_directly_lab', 'Supply Through Dealer') }}
                {{ FORM::checkbox('supply_directly','1') }}
            </div>

            <div class="form-group" id="provider_dealer_text">
                {{ FORM::label('provide_dealer_lab', 'Provider / Dealer') }}
                {{ FORM::textarea('provide_dealer', null, ['class'=>'form-control','size' => '10x5']) }}
            </div>

            <div class="form-group">
                {{ FORM::label('credit', 'Select your product Range') }}
                <br>
            <?php $inc = 1; ?>
            @foreach(@$cat[0] as $val)

            @if(@$cat[$val['id']])


            <div class="row row-centered">
                <button class="btn btn-info btn-sm label-success plus cr{{ $val['id'] }}" data-type="{{ $val['id'] }}"><span class="glyphicon glyphicon-plus rbs-green-plus"></span></button>
                <button class="btn btn-info btn-sm label-success minus {{ $val['id'] }}"><span class="glyphicon glyphicon-minus rbs-green-minus"></span></button>
                <div class="col-md-6 col-centered rbs-main-div">
                    <div class="label label-success mersal">{{ $val['cat_name'] }}</div>
                </div>
                <div class="row curious" id="{{ $val['id'] }}">
                    @foreach(@$cat[$val['id']] as $subval)
                        <div class="col-md-3 col-xs-6">
                            {{ FORM::checkbox('catid['.$subval['id'].']',$subval['id']) }}
                            {{ $subval['cat_name'] }}
                        </div>
                        <?php $inc++; ?>
                    @endforeach
                </div>
            </div>

                <br>
            @endif
            @endforeach
            </div>
            <div class="clearfix"></div>
            <div class="form-group">
                <div class="col-sm-4"></div>
                <div class="col-sm-3">
                    <br>
                {{ FORM::submit('Submit',['class'=>'btn btn-success btn-block btn-lg'])  }}
                    <br>
                </div>
                {{ FORM::close() }}
        </div>

    </div>

</section>
<!--about-->






<footer id="down-footer" class="footerbg white2">
    <div class="container">
        <div class="row">
            <!-- <div class="col-md-4">
              <div class="copyright">
                <p>Design <a href="http://rbsgroupindia.com/http://www.globaltrendz.com" class="orange2" target="_blank">Global Trendz</a></p>
              </div>
            </div> -->
            <div class="col-lg-12">

                <p class="text-center"> © <span id="year"><script>document.write(new Date().getFullYear())</script></span> RBS Group India .
                    All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer>

<script type="text/javascript" src="http://rbsgroupindia.com/js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/bootstrap.min.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/jquery-scrolltofixed.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/jquery.nav.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/jquery.isotope.js"></script>
<script src="http://rbsgroupindia.com/js/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/wow.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/jquery.mixitup.min.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/custom.js"></script>
<script src="http://rbsgroupindia.com/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/numberscroll.js"></script>
<script type="text/javascript" src="http://rbsgroupindia.com/js/jquery.stickit.js"></script>
<script src="http://rbsgroupindia.com/https://maps.googleapis.com/maps/api/js?v=3.exp"></script>


<!-- Frontpage Demo -->

<script>

    function init_map(){var myOptions = {zoom:10,center:new google.maps.LatLng(12.978788,80.205120),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(12.984119,80.207435)});infowindow = new google.maps.InfoWindow({content:'<strong>Title</strong><br />RBS Group India<br />'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);

    $('.products-filter').stickit();

    /*career-block1*/
    $(".outerblock1").mouseenter(function () {
        $(".outerblock1").find(".innerblock1").removeClass('hide');
        $(".outerblock2").addClass('hide');
    });

    $(".outerblock1").mouseleave(function () {
        $(".outerblock1").find(".innerblock1").addClass('hide');
        $(".outerblock2").removeClass('hide');
    });

    /*career-block2*/
    $(".outerblock2").mouseenter(function () {
        $(".outerblock2").find(".innerblock2").removeClass('hide');
        $(".outerblock1").addClass('hide');
        $(".outerblock2").css("margin-top", "0px");
    });

    $(".outerblock2").mouseleave(function () {
        $(".outerblock2").find(".innerblock2").addClass('hide');
        $(".outerblock1").removeClass('hide');
        $(".outerblock2").css("margin-top", "30px");
    });


    /*career-block3*/
    $(".outerblock3").mouseenter(function () {
        $(".outerblock3").find(".innerblock3").removeClass('hide');
        $(".outerblock4").addClass('hide');
    });

    $(".outerblock3").mouseleave(function () {
        $(".outerblock3").find(".innerblock3").addClass('hide');
        $(".outerblock4").removeClass('hide');
    });

    /*career-block2*/
    $(".outerblock4").mouseenter(function () {
        $(".outerblock4").find(".innerblock4").removeClass('hide');
        $(".outerblock3").addClass('hide');
        $(".outerblock4").css("margin-top", "0px");
    });

    $(".outerblock4").mouseleave(function () {
        $(".outerblock4").find(".innerblock4").addClass('hide');
        $(".outerblock3").removeClass('hide');
        $(".outerblock4").css("margin-top", "30px");
    });

    /*career-end*/

    /*
     $(".cap-bot1").mouseenter(function(){
     /*$("#ups-arrow").addClass('fa arrow3 fa-arrow-right');
     $(".cap-bot1").find('figcaption').removeClass('greybg');
     $(".cap-bot1").find('figcaption').addClass('orange');
     });

     $(".cap-bot1").mouseleave(function(){
     $("#ups-arrow").removeClass('fa arrow3 fa-arrow-right');
     $(".cap-bot1 figcaption").removeClass('orange');
     $(".cap-bot1 figcaption").addClass('greybg');
     });

     $(".cap-bot2").mouseenter(function(){
     $("#batteries-arrow").addClass('fa arrow3 fa-arrow-right');
     $(".cap-bot2 figcaption").removeClass('greybg');
     $(".cap-bot2 figcaption").addClass('orange');
     });

     $(".cap-bot2").mouseleave(function(){
     ("#batteries-arrow").removeClass('fa arrow3 fa-arrow-right');
     $(".cap-bot2 figcaption").removeClass('orange');
     $(".cap-bot2 figcaption").addClass('greybg');
     });
     */
    $(document).ready(function ($) {

        if ($(window).width() > 739) {
            //Add your javascript for large screens here

            $("#owl-example1").owlCarousel({
                autoPlay: 3500, //Set AutoPlay to 3 seconds
                autoplayTimeout: 2500,
                loop: true,
                autoHeight: true,
                items: 7,
                itemsDesktop: [1000, 4],
                itemsDesktopSmall: [900, 3],
                itemsTablet: [600, 2],
                itemsMobile: [480, 1],
            });
        } else {
            //Add your javascript for small screens here

            $("#owl-example1").owlCarousel({
                autoPlay: 3500, //Set AutoPlay to 3 seconds
                autoplayTimeout: 2500,
                autoHeight: true,
                pagination: false,

                items: 7,
                itemsDesktop: [1000, 4],
                itemsDesktopSmall: [900, 3],
                itemsTablet: [600, 3],
                itemsMobile: [480, 3],
            });
        }

        $('#product-container').mixItUp({
            effects: ['fade', 'blur']
        });

        $("body").on("click", ".products-filter li", function(){
            $('html,body').animate({
                scrollTop: $("#product-container").offset().top - 140
            }, 400);
        });


    });
</script>
<script>

    $(".curious").hide();
    $(".minus").hide();
    $(".mersal, .plus").click(function(){
        var as = $(this).attr('data-type');
        $("."+as).show();
       $("#"+as).show();
       $(".cr"+as).hide();
       $(".minus").click(function(){
          $("#"+as).hide();
          $("."+as).hide();
           $(".cr"+as).show();
          return false;
       });
       return false;
    });
    $('#supply_rbs_group').hide();
    $('#supply_through_dealer').hide();
    $('#provider_dealer_text').hide();

    $("#supp_s").attr('checked', 'checked');

    $('#manu_no').click(function(){
        $('#supply_rbs_group').hide();
        $('#supply_through_dealer').hide();
        $('#provider_dealer_text').hide();
        $("#supp_s").attr('checked', 'checked');
    });

    $('#manu_yes').click(function()
    {
        $("#supp_s").attr('checked', 'checked');
       $('#supply_rbs_group').show();
       $('#supp_no').click(function(){
           $('#supply_through_dealer, #provider_dealer_text').show();
       });
    });

    $('.carousel').carousel({
        interval: 3600,
        pause: false, //changes the speed
    });

    $('header').affix({
        offset: {
            top: 100
        }
    })

</script>

</body>
</html>