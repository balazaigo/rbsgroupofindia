<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 8/23/2017
 * Time: 4:16 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseCategory extends Model
{
    protected $table = 'purchase_categories';
    protected $fillable = ['category_id', 'po_id'];
}