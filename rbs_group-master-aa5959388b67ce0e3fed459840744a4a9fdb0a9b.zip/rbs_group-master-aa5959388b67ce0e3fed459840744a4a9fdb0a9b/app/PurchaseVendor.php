<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 8/23/2017
 * Time: 4:29 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseVendor extends Model
{
    protected $table = 'purchase_vendor';
    protected $fillable = ['purchase_id','vendor_id','status','description'];
}