<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/18/2017
 * Time: 7:21 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Categoryshow extends Model
{
    protected $table = 'cat';

    public function category()
    {
        return $this->belongsToMany('App\Category')->withTimestamps();
    }

    public function enq_vendor()
    {
        return $this->belongsTo('App\SupplierAcc','vid');
    }

    public function purchase_vendor()
    {
        return $this->belongsTo('App\SupplierAcc','vid');
    }
}