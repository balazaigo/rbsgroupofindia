<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/24/2017
 * Time: 6:18 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class Enquirymanagement extends Model
{

    protected $table = 'enquiries';

    public function vendors()
    {
        return $this->belongsToMany('App\SupplierAcc','enq_vendor','enq_id','vend_id')->withPivot('status','description');

    }

    public function enquirycategory()
    {
        return $this->belongsToMany('App\Category','enquiry_categories','category_id','enquiry_id');
    }

    public function employee()
    {
        return $this->belongsTo('App\User','emp_id')->withDefault([
            'name' => 'NULL'
        ]);
    }


}