<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 8/23/2017
 * Time: 8:00 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    protected $table = 'enquiry_status';
}