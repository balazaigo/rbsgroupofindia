<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;

class CustomerController extends Controller
{
    protected function index(Request $request)
    {
        \BREAD::putbc([
            'Customer' => 'rbsadmin/customer',

        ]);
        $search = $request->search;



        if($search)
        {
            $customer = Customer::where('customer_name','like','%'.$search.'%')->paginate(10);
        }
        else
        {
            $customer = Customer::orderBy('id')->paginate(10);
        }

//        $form_data = $customer->paginate(10);
        if($request['page']==null)
        {
            $request['page'] = 1;
            //dd($page);
        }

        $page = $request['page'] - 1;
        $page_quer = $page * 10;

//        $page_quer = 1;
        return view('admin.customer')->with([
            'customer' => $customer,
            'retain_search' => $search,
            'page_quer' => $page_quer
        ]);
    }

    protected function create()
    {
        \BREAD::putbc([
            'Customer' => 'rbsadmin/customer',
            'Create' => '#'
        ]);
        return view('admin.customer_create');
    }

    protected function store(Request $request)
    {
        $this->validate($request,[
            'customer_name' => 'required|min:3|max:50'
        ]);

        $customer = new Customer;
        $customer->customer_name = $request->customer_name;

        $customer->save();

        $request->session()->flash('customer_created','Created CustomerSuccessfully');
        return redirect()->action('CustomerController@index');
    }

    protected function edit($id)
    {
        \BREAD::putbc([
            'Customer' => 'rbsadmin/customer',
            'Edit' => '#'
        ]);
        $edit_customer = Customer::findorFail($id);

        return view('admin.customer_create')->with([
            'edit_customer' => $edit_customer
        ]);
    }

    protected function update($id, Request $request)
    {
        $this->validate($request,[
           'customer_name' => 'min:3|max:50'
        ]);

        $edit_customer = Customer::findorFail($id);

        $edit_customer->customer_name = $request->customer_name;
        $edit_customer->save();

        $request->session()->flash('customer_updated','Updated Customer');
        return redirect()->action('CustomerController@index');
    }

    protected function destroy($id, Request $request)
    {
        $delete_customer = Customer::findorFail($id);
        $delete_customer->delete();

        $request->session()->flash('customer_deleted','Deleted Customer');
        return redirect()->action('CustomerController@index');
    }
}
