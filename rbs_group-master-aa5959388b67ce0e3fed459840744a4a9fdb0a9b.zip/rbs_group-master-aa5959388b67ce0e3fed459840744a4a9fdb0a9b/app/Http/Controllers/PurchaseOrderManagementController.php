<?php

namespace App\Http\Controllers;

use App\Customer;
use Carbon\Carbon;
use App\PurchaseCategory;
use App\PurchaseVendor;
use Illuminate\Http\Request;
use App\PurchaseOrder;
use App\Enquirystatus;
use App\SupplierAcc;
use App\Category;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Categoryshow;
use App\Status;

class PurchaseOrderManagementController extends Controller
{
    private $pagination_length = 50;

    public function __construct()
    {
        /*$this->middleware(function ($request, $next) {
            if(\Auth::user()->urole == 2)
            {
                $request->session()->flash('not_admin','Not an admin');
                return redirect()->action('DashboardController@index');
            }
            else
            {
                return $next($request);
            }
        });*/
    }

    protected function index(Request $request)
    {

            \BREAD::putbc([
                'PO Management' => 'rbsadmin/purchase'
            ]);

            $req = [
                'sorting' => ['asc' => 'asc', 'desc' => 'desc'],
                'field' => [
                    'id' => 'id',
                    'po_date' => 'po_date',
                    'po_number' => 'po_number',
                    'rbs_offer_number' => 'rbs_offer_number',
                    'po_offer_value' => 'po_offer_value',
                    'customer' => 'customer',
                    'status' => 'status',
                ]
            ];

            $sort = $req['sorting'][($request['sort']) ? $request['sort'] : 'desc'];
            $field = $req['field'][($request['field']) ? $request['field'] : 'id'];

            $search = $request->search;


            $purchaseview = PurchaseOrder::orderBy($field, $sort);


            if ($search) {
                $purchaseview = $purchaseview->where('po_date', 'like', '%' . $search . '%')
                    ->orWhere('po_number', 'like', '%' . $search . '%')
                    ->orWhere('status', 'like', '%' . $search . '%');


                if (Auth::User()->urole == 1) {
                    $purchaseview = $purchaseview->orWhere('rbs_offer_number', 'like', '%' . $search . '%')
                        ->orWhere('po_offer_value', 'like', '%' . $search . '%')
                        ->orWhere('customer', 'like', '%' . $search . '%');
                }


            }

            if ($request->status_dropdown) {
                $purchaseview = $purchaseview->orWhere('status', '=', $request->status_dropdown);

            }

            $purchaseview = $purchaseview->paginate($this->pagination_length);
            if ($request['page'] == null) {
                $request['page'] = 1;
            }

            $page = $request['page'] - 1;
            $page_quer = $page * $this->pagination_length;

            $retain_status = Status::where('id', 1)->get();
            $stats = explode(",", $retain_status[0]['status']);

            return view('admin.po_view')->with([
                'purchase_view' => $purchaseview,
                'retain_search' => $search,
                'page_quer' => $page_quer,
                'stats' => $stats,
                'select' => $request->status_dropdown
            ]);

    }
    protected function create(Request $request)
    {
        if(Auth::User()->urole==1) {
            \BREAD::putbc([
                'PO Management' => 'rbsadmin/purchase',
                'Create' => 'rbsadmin/purchase/create'
            ]);

            $status = Enquirystatus::where('id', 1)->get();
            $stats = explode(",", $status[0]['status']);
            $vendor = SupplierAcc::orderBy('id')->get();
            $customer = Customer::orderBy('id')->get();
            $category_form = Category::orderBy('parent_id', 'ASC')->get();
            $catArray = [];
            foreach ($category_form as $val) {
                $catArray[$val->parent_id][] = [
                    'id' => $val->id,
                    'cat_name' => $val->cat_name,
                    'cat_status' => $val->cat_status,
                    'parent_id' => $val->parent_id,

                ];

            }
            return view('admin.po_create')->with([
                'stats' => $stats,
                'vendor' => $vendor,
                'customer' => $customer,
                'category' => $catArray
            ]);
        }
        else
        {
            $request->session()->flash('not_admin','Not an admin');
            return redirect()->action('DashboardController@index');
        }
    }

    protected function store(Request $request)
    {
        $this->validate($request,[
            'po_date' => 'required',
            'po_number' => 'required',
            //'rbs_offer_number' => 'required',
            //'po_offer_value' => 'required',
            'customer' => 'required',
            'description' => 'required',
            'status' => 'required',
            'notes_remarks' => 'max:1500',
            //'catid' => 'required',
            //'vendor' => 'required'
        ]);

        $date = Carbon::createFromFormat('m/d/Y', $request->po_date)->toDateString();
        $po_received = Carbon::createFromFormat('m/d/Y', $request->po_received)->toDateString();
        $po_delivery = Carbon::createFromFormat('m/d/Y', $request->po_delivery)->toDateString();

        $po_man = new PurchaseOrder;
        $po_man->po_date =  $date;
        $po_man->po_received =  $po_received;
        $po_man->po_delivery =  $po_delivery;
        $po_man->po_number = $request->po_number;
        $po_man->rbs_offer_number = $request->rbs_offer_number;
        $po_man->po_offer_value = $request->po_offer_value;
        $po_man->customer = $request->customer;
        $po_man->description = $request->description;
        $po_man->status = $request->status;
        $po_man->notes_remarks = $request->notes_remarks;

        $po_man->save();

        if($request->catid)
        {
            foreach($request->catid as $vval)
            {
                $purchasecategory = new PurchaseCategory;
                $purchasecategory->category_id = $vval;
                $purchasecategory->po_id = $po_man->id;
                $purchasecategory->save();
            }
        }

        if($request->vendor)
        {

            foreach($request->vendor as $val)
            {
                $purchasevendor = new PurchaseVendor;
                $purchasevendor->purchase_id = $po_man->id;
                $purchasevendor->vendor_id = $val;
                $purchasevendor->status = "";
                $purchasevendor->description = "";
                $purchasevendor->save();
            }
        }



        $request->session()->flash('purchase_created','Your Purchase Order Has been successfully registered');
        return redirect()->action('PurchaseOrderManagementController@index');
    }

    protected function edit($id)
    {
        \BREAD::putbc([
            'PO Management' => 'rbsadmin/purchase',
            'Edit' => 'rbsadmin/purchase/edit'
        ]);

        $purchase_id = PurchaseOrder::findorfail($id);
        $staff = User::where('urole', '2')->get();
        $status = Enquirystatus::where('id',1)->get();
        $stats = explode(",",$status[0]['status']);
        $vendor = SupplierAcc::orderBy('id')->get();
        $customer = Customer::orderBy('id')->get();

        $purcat = PurchaseCategory::where('po_id', $id)->get();

        $category_form = Category::orderBy('parent_id','ASC')->get();

        $purchase_select_edit = $purchase_id->vendors;

        $purchase_vend_selc = [];
        foreach($purchase_select_edit as $val)
        {
            $purchase_vend_selc[] = $val->id;
        }

        $catArray = [];

        foreach ($category_form as $val)
        {
            $catArray[$val->parent_id][] = [
                'id' => $val->id,
                'cat_name' => $val->cat_name,
                'cat_status' => $val->cat_status,
                'parent_id' => $val->parent_id,

            ];

        }

        $purajcat = [];

        foreach($purcat as $val)
        {
            $purajcat[] = $val->category_id;
        }

        return view('admin.po_create')->with([
            'po_edit' => $purchase_id,
            'ven_edit' => $vendor,
            'ven_select_edit' => $purchase_vend_selc,
            'stats' => $stats,
            'customer' => $customer,
            'category' => $catArray,
            'category_select' => $purajcat,
        ]);
    }

    protected function update($id, Request $request)
    {
        if(!$request['view'])
        {
            $this->validate($request, [
                'po_date' => 'required',
                'po_number' => 'required',
                'description' => 'required',
                'status' => 'required',
                'notes_remarks' => 'max:1500',
                //'catid' => 'required',
                //'vendor' => 'required'
            ]);
            if (Auth::User()->urole == 1) {
                $this->validate($request, [
                    'rbs_offer_number' => 'required',
                    'po_offer_value' => 'required',
                    'customer' => 'required',
                ]);
            }


            $date = Carbon::createFromFormat('m/d/Y', $request->po_date)->toDateString();
            $po_received = Carbon::createFromFormat('m/d/Y', $request->po_received)->toDateString();
            $po_delivery = Carbon::createFromFormat('m/d/Y', $request->po_delivery)->toDateString();

            $upd_purchase = PurchaseOrder::findorfail($id);

            $upd_purchase->po_date = $date;
            $upd_purchase->po_number = $request->po_number;
            $upd_purchase->po_received = $po_received;
            $upd_purchase->po_delivery = $po_delivery;
            $upd_purchase->rbs_offer_number = $request->rbs_offer_number;
            $upd_purchase->po_offer_value = $request->po_offer_value;
            $upd_purchase->customer = $request->customer;
            $upd_purchase->description = $request->description;
            $upd_purchase->status = $request->status;
            $upd_purchase->notes_remarks = $request->notes_remarks;

            $upd_purchase->save();
        }

        if($request->catid)
        {
            $existing_category = PurchaseCategory::select('category_id')->where('po_id',$id)->get();

            /***for fetching old records in db**/
            $existing_cat = [];

            foreach($existing_category as $val)
            {
                $existing_cat[] =  $val['category_id'];
            }

            /**for fetching user record and compare with old record***/

            $new_cat = [];

            foreach($request->catid as $val)
            {
                $new_cat[] = (int)$val;
            }



            $collection = collect($existing_cat);
            $diff = $collection->diff($new_cat);

            $get_deleted = $diff->all();

            PurchaseCategory::wherein('category_id',$get_deleted)->where('po_id',$id)->delete();

            foreach($request->catid as $val)
            {
                $enq_cat = PurchaseCategory::updateorcreate(
                    ['category_id' => $val,'po_id' => $id],
                    ['category_id' => $val,'po_id' => $id]
                );
            }

        }
        else
        {
            PurchaseCategory::where('po_id',$id)->delete();
        }

        if($request->vendor)
        {
            $existing_vendor = PurchaseVendor::select('vendor_id')->where('purchase_id',$id)->get();
            /***for fetching old records in db**/
            $existing_vend = [];

            foreach($existing_vendor as $val)
            {
                $existing_vend[] =  $val['vendor_id'];
            }

            /**for fetching user record and compare with old record***/

            $new_vend = [];

            foreach($request->vendor as $val)
            {
                $new_vend[] = (int)$val;
            }

            $collection = collect($existing_vend);
            $diff = $collection->diff($new_vend);

            $get_deleted = $diff->all();

            PurchaseVendor::wherein('vendor_id',$get_deleted)->where('purchase_id',$id)->delete();

            $exist_vendor = PurchaseVendor::wherein('vendor_id',$request->vendor)->where('purchase_id',$id)->get();

            $old_vend = [];
            foreach($exist_vendor as $vval)
            {
                $old_vend[] = $vval['vendor_id'];
            }

            foreach ($request->vendor as $val)
            {
                if(!in_array($val,$old_vend))
                {
                    $enq_vendor = new PurchaseVendor;
                    $enq_vendor->purchase_id = $id;
                    $enq_vendor->vendor_id = $val;
                    $enq_vendor->status = '';
                    $enq_vendor->description = '';
                    $enq_vendor->save();
                }
            }
        }
        else
        {
            PurchaseVendor::where('purchase_id',$id)->delete();
        }

        if($request['view']=="ok")
        {
            return redirect('rbsadmin/purchase/'.$id);
        }

        $request->session()->flash('purchase_updated', 'enquiry_updated');
        return redirect()->action('PurchaseOrderManagementController@index');
    }

    protected function view($id)
    {
        \BREAD::putbc([
            'Purchase Order' => 'rbsadmin/enquiry',
            'View' => 'rbsadmin/enquiry/view'
        ]);
        $view_purchase = PurchaseOrder::findorfail($id);
        $view_purchase_vendor = $view_purchase->vendors;
        $status = Status::where('id',1)->get();
        $stats = explode(",",$status[0]['status_vendor']);
        $category_form = Category::orderBy('parent_id', 'ASC')->get();

        $catArray = [];

        foreach ($category_form as $val) {
            $catArray[$val->parent_id][] = [
                'id' => $val->id,
                'cat_name' => $val->cat_name,
                'cat_status' => $val->cat_status,
                'parent_id' => $val->parent_id,

            ];

        }

        $purcat = PurchaseCategory::where('po_id', $id)->get();
        $purajcat = [];

        foreach($purcat as $val)
        {
            $purajcat[] = $val->category_id;
        }

        $purchase_vend_selc = [];
        foreach($view_purchase_vendor as $val)
        {
            $purchase_vend_selc[] = $val->id;
        }

        return view('admin.po_ind_view')->with([
            'view_same' => $view_purchase,
            'view_vendor' => $view_purchase_vendor,
            'stats' => $stats,
            'category' => $catArray,
            'category_select' => $purajcat,
            'ven_select_edit' => $purchase_vend_selc
        ]);
    }

    protected function destroy($id, Request $request)
    {
        $delete = PurchaseOrder::findOrFail($id);
        $delete->delete();

        $request->session()->flash('deleted_purchase_successfully', 'Deleted Enquiry successfully.');

        return redirect()->action('PurchaseOrderManagementController@index');
    }

    protected function ajaxCategory(Request $request)
    {
        $categoryid = (array) json_decode($request->catdata);
        $vendors = [];
        $purchasevend = Categoryshow::whereIn('cid',$categoryid)->get();
        foreach($purchasevend as $enq){
            $vends = $enq->purchase_vendor;
            if($vends) $vendors[$vends->id] = [$vends->company_name];

        }

        return response()->json($vendors);
    }

    protected function save($vendorid, $purchaseid, Request $request)
    {
        $stat = PurchaseVendor::updateorcreate([
            'vendor_id' => $vendorid,
            'purchase_id' => $purchaseid
        ],
            [
                'status' => count($request->status_vendor) ? $request->status_vendor : 0,
                'description' => count($request->vendor_desc) ? $request->vendor_desc : "",
            ]);


        $request->session()->flash('stats_dup','statusvendupdated');
        return redirect()->action('PurchaseOrderManagementController@view',['id' => $purchaseid]);
    }
}