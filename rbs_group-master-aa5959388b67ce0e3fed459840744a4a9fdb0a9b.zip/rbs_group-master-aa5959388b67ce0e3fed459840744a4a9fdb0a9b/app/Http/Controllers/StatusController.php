<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Status;

class StatusController extends Controller
{
    protected function index()
    {
        $getStatus = Status::where('id',1)->get();

        return view('admin.status')->with([
            'status' => $getStatus,
        ]);
    }
    protected function store(Request $request)
    {
        $storeStatus = Status::findorfail(1);
        $storeStatus->status = $request->status;
        $storeStatus->status_vendor = $request->status_vendor;
        $storeStatus->save();

        $request->session()->flash('status_update', 'Status Updated Successfully');
        return redirect()->action('StatusController@index');
    }
}
