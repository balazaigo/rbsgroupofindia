<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/4/2017
 * Time: 2:08 PM
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
    private $active = '';

    public function __construct()
    {
        //
    }

    protected function index()
    {
        \BREAD::putbc([
            'Category' => 'rbsadmin/category',
        ]);
        $cat = Category::orderBy('parent_id', 'ASC')->get();
        $catArray = [];

        foreach ($cat as $val) {
            $catArray[$val->parent_id][] = [
                'id' => $val->id,
                'cat_name' => $val->cat_name,
                'cat_status' => $val->cat_status,
                'parent_id' => $val->parent_id,

            ];

        }
        //dd($catArray);
        return view('admin.cat')->with([
            'cat' => $catArray,
        ]);
    }

    protected function create()
    {
        \BREAD::putbc([
            'Category' => 'rbsadmin/category',
            'Create' => 'rbsadmin/category/create'
        ]);
        $cat = Category::where('parent_id', '0')->get();
        return view('admin.cat_create')->with([
            'cat' => $cat
        ]);
    }

    protected function store(Request $request)
    {
        $this->validate($request, [
            'cat_name' => 'required|max:100|min:4',
        ]);

        $new_category = new Category;
        $new_category->cat_name = $request->cat_name;
        $new_category->parent_id = $request->parent_id;
        $new_category->cat_status = "1";
        $new_category->save();

        $request->session()->flash('success_new_category', 'New category Has Been created Successfully');

        return redirect()->action('CategoryController@index');
    }

    protected function edit($id)
    {
        \BREAD::putbc([
            'Category' => 'rbsadmin/category',
            'Edit' => ''
        ]);
        $cat = Category::findorfail($id);
        return view('admin.cat_create')->with([
            'edit' => $cat
        ]);
    }

    protected function update($id, Request $request)
    {
        $this->validate($request, [
            'cat_name' => 'min:4|max:100'
        ]);

        $edit_cat = Category::findorfail($id);

        $edit_cat->cat_name = $request->cat_name;

        $edit_cat->save();

        $request->session()->flash('success_edit_category', 'Category Name Edited');
        return redirect()->action('CategoryController@index');
    }

    protected function destroy($id, Request $request)
    {
        $delete = Category::findorfail($id);
        $delete->delete();

        $childdel = Category::where('parent_id', $id);
        $childdel->delete();

        $request->session()->flash('Success_delete_category', 'Deleted');
        return redirect()->action('CategoryController@index');



    }
}