<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    protected function index()
    {
        \BREAD::putbc([
            'My Profile' => 'rbsadmin/profile',
        ]);

        return view('admin.profileform');
    }

    protected function resetpassword(Request $request)
    {

        $this->validate($request, [
            'password' => 'required|min:5|confirmed',
            'password_confirmation' => 'required|min:5'
        ]);

        $user = $request->user();
        $user->password = \Hash::make($request->password);
        $user->save();

        $request->session()->flash('success','Your Password Updated Successfully');
        return redirect()->back();

    }

    protected function prof_upd(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|string|min:1|max:35',
            'email' => 'required|email'
        ]);

        $user = $request->user();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->save();

        $request->session()->flash('name_success', 'Your Details updated successfully');
        return redirect()->back();
    }

}
