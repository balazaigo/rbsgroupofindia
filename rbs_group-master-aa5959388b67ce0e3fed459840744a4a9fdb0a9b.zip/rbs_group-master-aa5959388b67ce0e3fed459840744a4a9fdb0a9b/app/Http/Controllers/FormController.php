<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/17/2017
 * Time: 5:57 PM
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SupplierAcc;
use App\Category;
use App\Categoryshow;

class FormController extends Controller
{
    public function __construct()
    {
        //
    }
    protected function index()
    {
        echo "welcome";
    }
    protected function create()
    {
        $cat = Category::orderBy('cat_name', 'ASC')->get();
        $catArray = [];

        foreach ($cat as $val) {
            $catArray[$val->parent_id][] = [
                'id' => $val->id,
                'cat_name' => $val->cat_name,
                'cat_status' => $val->cat_status,
                'parent_id' => $val->parent_id,

            ];

        }

        return view('form')->with([
           'cat' => $catArray
        ]);
    }
    protected function store(Request $request)
    {
        $this->validate($request, [
            'company_name' => 'required|max:35',
            'sm_contactperson' => 'required|max:30|min:3',
            'sm_phone' => 'required|max:28',
            'sm_mobile' => 'required|max:13|min:10',
            'sm_email' => 'email|unique:supplieracc,sm_mailid|required',
            'fc_contactperson' => 'max:30|nullable',
            'fc_phone' => 'nullable|max:13',
            'fc_mobile' => 'nullable|max:13',
            'fc_email' => 'nullable|email',
            'qt_contactperson' => 'nullable|max:35',
            'qt_phone' => 'nullable|max:13',
            'qt_mobile' => 'nullable|max:13',
            'qt_email' => 'nullable|email',
            'ohqo_contactperson' => 'nullable|max:35',
            'ohqo_phone' => 'nullable|max:13',
            'ohqo_mobile' => 'nullable|max:13',
            'ohqo_email' => 'nullable|email',
            'ac_contactperson' => 'max:35',
            'ac_phone' => 'nullable|max:13',
            'ac_mobile' => 'nullable|max:13',
            'ac_email' => 'nullable|email',
            'dd_contactperson' => 'max:35',
            'dd_phone' => 'nullable|max:13',
            'dd_mobile' => 'nullable|max:13',
            'dd_email' => 'nullable|email',
            'bank_details' => 'max:100',
            'gstin' => 'required',
            'overallcapability' => 'max:1500',
            'reference' => 'max:100',
            'creditterms' => 'max:100',
            'manufacture_dealer' => 'required|in:1,2'
        ]);
        if($request->manufacture_dealer == '1')
        {
            $this->validate($request,[
                'supply_s' => 'required|in:1,2'
            ]);
            if($request->supply_s == '2')
                $this->validate($request, [
                    'supply_directly' => 'required',
                ]);

                if($request->supply_directly){
                $this->validate($request,[
                    'provide_dealer' => 'required|max:100'
                ]);
                }
        }
        $supplieracc = new SupplierAcc;
        $supplieracc->company_name = $request->company_name;
        $supplieracc->sm_contactperson = $request->sm_contactperson;
        $supplieracc->sm_phone = $request->sm_phone;
        $supplieracc->sm_mobile = $request->sm_mobile;
        $supplieracc->sm_mailid = $request->sm_email;
        $supplieracc->fc_contactperson = $request->fc_contactperson;
        $supplieracc->fc_phone = $request->fc_phone;
        $supplieracc->fc_mobile = $request->fc_mobile;
        $supplieracc->fc_mailid = $request->fc_email;
        $supplieracc->qt_contactperson = $request->qt_contactperson;
        $supplieracc->qt_phone = $request->qt_phone;
        $supplieracc->qt_mobile = $request->qt_mobile;
        $supplieracc->qt_mailid = $request->qt_email;
        $supplieracc->ohqo_contactperson = $request->ohqo_contactperson;
        $supplieracc->ohqo_phone = $request->ohqo_phone;
        $supplieracc->ohqo_mobile = $request->ohqo_mobile;
        $supplieracc->ohqo_mailid = $request->ohqo_email;
        $supplieracc->ac_contactperson = $request->ac_contactperson;
        $supplieracc->ac_phone = $request->ac_phone;
        $supplieracc->ac_mobile = $request->ac_mobile;
        $supplieracc->ac_mailid = $request->ac_email;
        $supplieracc->dd_contactperson = $request->dd_contactperson;
        $supplieracc->dd_phone = $request->dd_phone;
        $supplieracc->dd_mobile = $request->dd_mobile;
        $supplieracc->dd_mailid = $request->dd_email;
        $supplieracc->bank_details = $request->bank_details;
        $supplieracc->gstin = $request->gstin;
        $supplieracc->overall_capability = $request->overallcapability;
        $supplieracc->referenceclients = $request->reference;
        $supplieracc->creditterms = $request->creditterms;
        $supplieracc->manufacture_dealer = $request->manufacture_dealer;
        if($request->manufacture_dealer == '1')
        {
            $supplieracc->supply_directly = $request->supply_directly;
            if($request->supply_directly == '2')
            {
                $supplieracc->supply_s = $request->supply_s;
                $supplieracc->provide_dealer = $request->provide_dealer;

            }

        }
        else
        {
            $supplieracc->supply_directly = '0';
            $supplieracc->supply_s = '0';
            $supplieracc->provide_dealer = '0';
        }
        $supplieracc->save();

        if($request->catid)
        {
            foreach ($request->catid as $val)
            {
                $catshow = new Categoryshow;
                $catshow->vid = $supplieracc->id;
                $catshow->cid = $val;
                $catshow->save();
            }
        }
        $request->session()->flash('forminserted', 'FormHasbeensuccfff');

        return redirect()->action('FormController@create');
    }
    protected function edit()
    {
        //
    }
}