<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/18/2017
 * Time: 11:45 AM
 */

namespace App\Http\Controllers;

use App\SupplierAcc;
use Illuminate\Http\Request;
use App\Category;
use App\Categoryshow;

class AdminFormController extends Controller
{

    private $pagination_length =50;
    public function _construct()
    {

        //
    }

    protected function index(Request $request)
    {
        \BREAD::putbc([
            'Vendor' => 'rbsadmin/form',
        ]);

        $search = $request->search;
        $req = [
            'sorting' => ['asc' => 'asc','desc' => 'desc'],
            'field' =>[
                'id' => 'id',
                'company_name' => 'company_name',
                'sm_contactperson' => 'sm_contactperson',
                'sm_phone' => 'sm_phone',
                'sm_mobile' => 'sm_mobile',
                'sm_mailid' => 'sm_mailid',
            ]
        ];


        $sort = $req['sorting'][($request['sort']) ? $request['sort'] : 'desc'];
        $field = $req['field'][($request['field']) ? $request['field'] : 'id'];

            $form_data = SupplierAcc::orderBy($field,$sort);

        if($search)
        {
            $form_data = $form_data->where('company_name','like','%'.$search.'%')
                ->orWhere('sm_contactperson','like','%'.$search.'%')
                ->orWhere('sm_phone','like','%'.$search.'%')
                ->orWhere('sm_mobile','like','%'.$search.'%')
                ->orWhere('sm_mailid','like','%'.$search.'%')->wherehas('categories', function ($q) use ($search){
                    $q->where('cat_name','like','%'.$search.'%');
                });
        }

        $form_data = $form_data->paginate($this->pagination_length);
        if($request['page']==null)
        {
            $request['page'] = 1;
            //dd($page);
        }

        $page = $request['page']-1;
        $page_quer = $page * $this->pagination_length;



        return view('admin.formdata')->with([
            'form_fields' => $form_data,
            'retain_search' => $search,
            'page_quer' => $page_quer
        ]);
    }
    protected function create()
    {
        \BREAD::putbc([
            'Vendor' => 'rbsadmin/form',
            'Create Vendor' => 'rbsadmin/form/create'
        ]);
        $category_form = Category::orderBy('parent_id','ASC')->get();

        $catArray = [];

        foreach ($category_form as $val) {
            $catArray[$val->parent_id][] = [
                'id' => $val->id,
                'cat_name' => $val->cat_name,
                'cat_status' => $val->cat_status,
                'parent_id' => $val->parent_id,

            ];

        }
        return view('admin.formedit')->with([
            'category' => $catArray
        ]);
    }

    protected function store(Request $request)
    {

        $this->validate($request, [
            'company_name' => 'required|max:35',
            'sm_contactperson' => 'required|max:30|min:3',
            'sm_phone' => 'required|max:28',
            'sm_mobile' => 'required|max:13|min:10',
            'sm_mailid' => 'email|unique:supplieracc,sm_mailid|required',
            'fc_contactperson' => 'nullable|max:30|min:3',
            'fc_phone' => 'nullable|max:13|min:10',
            'fc_mobile' => 'nullable|max:13|min:10',
            'fc_mailid' => 'nullable|email',
            'qt_contactperson' => 'nullable|max:35|min:3',
            'qt_phone' => 'nullable|max:13|min:10',
            'qt_mobile' => 'nullable|max:13|min:10',
            'qt_mailid' => 'nullable|email',
            'ohqo_contactperson' => 'nullable|max:35|min:3',
            'ohqo_phone' => 'nullable|max:13|min:10',
            'ohqo_mobile' => 'nullable|max:13|min:10',
            'ohqo_mailid' => 'nullable|email',
            'ac_contactperson' => 'nullable|max:35',
            'ac_phone' => 'nullable|max:13|min:10',
            'ac_mobile' => 'nullable|max:13|min:10',
            'ac_mailid' => 'nullable|email',
            'dd_contactperson' => 'nullable|max:35',
            'dd_phone' => 'nullable|max:13|min:10',
            'dd_mobile' => 'nullable|max:13|min:10',
            'dd_mailid' => 'nullable|email',
            'bank_details' => 'nullable|max:50',
            'gstin' => 'required',
            'overall_capability' => 'nullable|max:1500',
            'referenceclients' => 'nullable|max:40',
            'creditterms' => 'nullable|max:40',
            'manufacture_dealer' => 'required|in:1,2',
            //'catid' => 'required'
        ]);

        if($request->manufacture_dealer == '1')
        {
            $this->validate($request,[
                'supply_s' => 'required|in:1,2'
            ]);
            if($request->supply_s == '2')
            {
                $this->validate($request, [
                    'supply_directly' => 'required',
                    'provide_dealer' => 'required'
                ]);

                if($request->supply_directly == 1)
                {
                        $this->validate($request,[
                            'supply_directly' => 'required',
                            'provide_dealer' => 'required|max:100'
                        ]);
                }
                else
                {
                    $this->validate($request,[
                       'supply_directly' => 'required'

                    ]);
                }
            }
        }

        $supplieracc = new SupplierAcc;
        $supplieracc->company_name = $request->company_name;
        $supplieracc->sm_contactperson = $request->sm_contactperson;
        $supplieracc->sm_phone = $request->sm_phone;
        $supplieracc->sm_mobile = $request->sm_mobile;
        $supplieracc->sm_mailid = $request->sm_mailid;
        $supplieracc->fc_contactperson = $request->fc_contactperson;
        $supplieracc->fc_phone = $request->fc_phone;
        $supplieracc->fc_mobile = $request->fc_mobile;
        $supplieracc->fc_mailid = $request->fc_mailid;
        $supplieracc->qt_contactperson = $request->qt_contactperson;
        $supplieracc->qt_phone = $request->qt_phone;
        $supplieracc->qt_mobile = $request->qt_mobile;
        $supplieracc->qt_mailid = $request->qt_mailid;
        $supplieracc->ohqo_contactperson = $request->ohqo_contactperson;
        $supplieracc->ohqo_phone = $request->ohqo_phone;
        $supplieracc->ohqo_mobile = $request->ohqo_mobile;
        $supplieracc->ohqo_mailid = $request->ohqo_mailid;
        $supplieracc->ac_contactperson = $request->ac_contactperson;
        $supplieracc->ac_phone = $request->ac_phone;
        $supplieracc->ac_mobile = $request->ac_mobile;
        $supplieracc->ac_mailid = $request->ac_mailid;
        $supplieracc->dd_contactperson = $request->dd_contactperson;
        $supplieracc->dd_phone = $request->dd_phone;
        $supplieracc->dd_mobile = $request->dd_mobile;
        $supplieracc->dd_mailid = $request->dd_mailid;
        $supplieracc->bank_details = $request->bank_details;
        $supplieracc->gstin = $request->gstin;
        $supplieracc->overall_capability = $request->overall_capability;
        $supplieracc->referenceclients = $request->referenceclients;
        $supplieracc->creditterms = $request->creditterms;
        $supplieracc->manufacture_dealer = $request->manufacture_dealer;
        if($request->manufacture_dealer == '1')
        {

            if($request->supply_s == '2')
            {
                $supplieracc->supply_s = $request->supply_s;
                if($request->supply_directly == 1)
                {
                $supplieracc->supply_directly = $request->supply_directly;
                    $supplieracc->provide_dealer = $request->provide_dealer;
                }
                else
                {
                    $supplieracc->supply_directly = "0";
                    $supplieracc->provide_dealer = "0";
                }

            }
            else
            {
                $supplieracc->supply_s = "0";
                $supplieracc->provide_dealer = "0";
            }
        }
        else
        {
            $supplieracc->supply_directly = "0";
            $supplieracc->supply_s = "0";
            $supplieracc->provide_dealer = "0";
        }
        $supplieracc->save();

        if($request->catid){
            foreach($request->catid as $val)
            {
                $catshow = new Categoryshow;
                $catshow->vid = $supplieracc->id;
                $catshow->cid = $val;
                $catshow->save();
            }
        }

        $request->session()->flash('company_form_created', 'company_form_created_successfully');
        return redirect()->action('AdminFormController@index');

    }

    protected function edit($id)
    {
        \BREAD::putbc([
            'Vendor' => 'rbsadmin/form',
            'Edit' => 'rbsadmin/form/edit'
        ]);
        $category_form = Category::orderBy('parent_id', 'ASC')->get();

        $catArray = [];

        foreach ($category_form as $val) {
            $catArray[$val->parent_id][] = [
                'id' => $val->id,
                'cat_name' => $val->cat_name,
                'cat_status' => $val->cat_status,
                'parent_id' => $val->parent_id,

            ];

        }
        $form_edit = SupplierAcc::findorfail($id);
        $edit_cat = $form_edit->categories;

        $catids = [];
        foreach($edit_cat as $cats){
            $catids[] = $cats->id;
        }

        return view('admin.formedit')->with([
           'form_edit' => $form_edit,
            'category' => $catArray,
            'cat_selected' => $catids
        ]);
    }

    protected function update($id, Request $request)
    {

        $this->validate($request, [
            'company_name' => 'max:35',
            'sm_contactperson' => 'max:30|min:3',
            'sm_phone' => 'max:28',
            'sm_mobile' => 'max:13|min:10',
            'sm_email' => 'email',
            'fc_contactperson' => 'nullable|max:30|min:3',
            'fc_phone' => 'nullable|max:13|min:10',
            'fc_mobile' => 'nullable|max:13|min:10',
            'fc_mailid' => 'nullable|email',
            'qt_contactperson' => 'nullable|max:35|min:3',
            'qt_phone' => 'nullable|max:13|min:10',
            'qt_mobile' => 'nullable|max:13|min:10',
            'qt_mailid' => 'nullable|email',
            'ohqo_contactperson' => 'nullable|max:35',
            'ohqo_phone' => 'nullable|max:13',
            'ohqo_mobile' => 'nullable|max:13',
            'ohqo_mailid' => 'nullable|email',
            'ac_contactperson' => 'nullable|max:35',
            'ac_phone' => 'nullable|max:13|min:10',
            'ac_mobile' => 'nullable|max:13|min:10',
            'ac_mailid' => 'nullable|email',
            'dd_contactperson' => 'nullable|max:35',
            'dd_phone' => 'nullable|max:13|min:10',
            'dd_mobile' => 'nullable|max:13|min:10',
            'dd_mailid' => 'nullable|email',
            'bank_details' => 'nullable|max:100',
            'gstin' => 'required',
            'overall_capability' => 'nullable|max:1500',
            'referenceclients' => 'nullable|max:100',
            'creditterms' => 'nullable|max:100',
            'catid' => 'required'
        ]);

        $form_update = SupplierAcc::findorfail($id);

        $form_update->company_name = $request->company_name;
        $form_update->sm_contactperson = $request->sm_contactperson;
        $form_update->sm_phone = $request->sm_phone;
        $form_update->sm_mobile = $request->sm_mobile;
        $form_update->sm_mailid = $request->sm_mailid;
        $form_update->fc_contactperson = $request->fc_contactperson;
        $form_update->fc_phone = $request->fc_phone;
        $form_update->fc_mobile = $request->fc_mobile;
        $form_update->fc_mailid = $request->fc_mailid;
        $form_update->qt_contactperson = $request->qt_contactperson;
        $form_update->qt_phone = $request->qt_phone;
        $form_update->qt_mobile = $request->qt_mobile;
        $form_update->qt_mailid = $request->qt_mailid;
        $form_update->ohqo_contactperson = $request->ohqo_contactperson;
        $form_update->ohqo_phone = $request->ohqo_phone;
        $form_update->ohqo_mobile = $request->ohqo_mobile;
        $form_update->ohqo_mailid = $request->ohqo_mailid;
        $form_update->ac_contactperson = $request->ac_contactperson;
        $form_update->ac_phone = $request->ac_phone;
        $form_update->ac_mobile = $request->ac_mobile;
        $form_update->ac_mailid = $request->ac_mailid;
        $form_update->dd_contactperson = $request->dd_contactperson;
        $form_update->dd_phone = $request->dd_phone;
        $form_update->dd_mobile = $request->dd_mobile;
        $form_update->dd_mailid = $request->dd_mailid;
        $form_update->bank_details = $request->bank_details;
        $form_update->gstin = $request->gstin;
        $form_update->overall_capability = $request->overall_capability;
        $form_update->referenceclients = $request->referenceclients;
        $form_update->creditterms = $request->creditterms;
        $form_update->manufacture_dealer = $request->manufacture_dealer ? $request->manufacture_dealer : 0;
        $form_update->supply_directly = $request->supply_directly ? $request->supply_directly : 0;
        $form_update->provide_dealer = $request->provide_dealer ? $request->provide_dealer : 0;
        $form_update->save();


        $form_delete = Categoryshow::where('vid',$id);
        $form_delete->delete();

        if($request->catid){
            foreach($request->catid as $val)
            {
                $catshow = new Categoryshow;
                $catshow->vid = $id;
                $catshow->cid = $val;
                $catshow->save();
            }
        }



        $request->session()->flash('company_form_updated', 'company_form_updated_successfully');
        return redirect()->action('AdminFormController@index');
    }

    protected function destroy($id, Request $request)
    {
        $form_delete = SupplierAcc::findorfail($id);
        $form_delete->delete();
        $request->session()->flash('delete_form_success','Deleted the company details successfully');
        return redirect()->action('AdminFormController@index');
    }

    protected function view($id)
    {
        \BREAD::putbc([
            'Vendor' => 'rbsadmin/form',
            'View' => 'rbsadmin/form/view'
        ]);
        $view_form  =  SupplierAcc::findorfail($id);
        $category = $view_form->categories;

        return view('admin.adminformview')->with([
            'view_data' => $view_form,
            'view_d' => $category
        ]);
    }
}