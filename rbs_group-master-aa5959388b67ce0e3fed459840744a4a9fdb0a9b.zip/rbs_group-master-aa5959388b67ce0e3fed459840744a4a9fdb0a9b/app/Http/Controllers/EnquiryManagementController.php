<?php

namespace App\Http\Controllers;

use App\Categoryshow;
use App\Customer;
use App\EnquiryVendor;
use App\Status;
use App\VendorStatus;
use Illuminate\Http\Request;
use App\Enquirymanagement;
use App\User;
use Carbon\Carbon;
use App\Enquirystatus;
use App\SupplierAcc;
use Illuminate\Support\Facades\Auth;
use App\Category;
use App\EnquiryCategory;
use Illuminate\Support\Collection;


class EnquiryManagementController extends Controller
{
    private $pagination_length = 50;

    public function __construct()
    {
        /*$this->middleware(function ($request, $next) {
            if(\Auth::user()->urole == 2)
            {
                $request->session()->flash('not_admin','Not an admin');
                return redirect()->action('DashboardController@index');
            }
            else
            {
                return $next($request);
            }
        });*/
    }

    protected function index(Request $request)
    {
        \BREAD::putbc([
            'Enquiry' => 'rbsadmin/enquiry'
        ]);

       $req = [
            'sorting' => ['asc' => 'asc','desc' => 'desc'],
            'field' =>[
                'id' => 'id',
                'enquiry_date' => 'enquiry_date',
                'rfq_number' => 'rfq_number',
                'rbs_offer_number' => 'rbs_offer_number',
                'offer_value' => 'offer_value',
                'customer' => 'customer',
                'status' => 'status',
                'emp' => 'emp_id',
            ]
        ];


        $sort = $req['sorting'][($request['sort']) ? $request['sort'] : 'desc'];
        $field = $req['field'][($request['field']) ? $request['field'] : 'id'];

        $search = $request->search;


        $enqview = Enquirymanagement::orderBy($field,$sort);


        if($search)
        {
            $enqview = $enqview->where('enquiry_date','like','%'.$search.'%')
                ->orWhere('rfq_number','like','%'.$search.'%')
                ->orWhere('status','like','%'.$search.'%')
                ->wherehas('employee', function ($q) use ($search){
                    $q->where('name','like','%'.$search.'%');
                });


            if(Auth::User()->urole==1)
            {
                $enqview = $enqview->orWhere('rbs_offer_number', 'like', '%' . $search . '%')
                    ->orWhere('offer_value', 'like', '%' . $search . '%')
                    ->orWhere('customer', 'like', '%' . $search . '%');
            }



        }
        if($request->status_dropdown)
        {
            $enqview = $enqview->orWhere('status', '=', $request->status_dropdown);

        }

        $enqview = $enqview->paginate($this->pagination_length);
        if($request['page']==null)
        {
            $request['page'] = 1;
        }

        $page = $request['page']-1;
        $page_quer = $page * $this->pagination_length;

        $retain_status = Status::where('id',1)->get();
        $stats = explode(",",$retain_status[0]['status']);



        return view('admin.enquiry_view')->with([
            'enq_view' => $enqview,
            'retain_search' => $search,
            'page_quer' => $page_quer,
            'stats' => $stats,
            'select' => $request->status_dropdown
        ]);
    }

    protected function create(Request $request)
    {
        if(Auth::User()->urole==1) {
            \BREAD::putbc([
                'Enquiry' => 'rbsadmin/enquiry',
                'Create' => '#'
            ]);

            $staff = User::where('urole', '2')->get();
            $status = Enquirystatus::where('id', 1)->get();
            $stats = explode(",", $status[0]['status']);
            $vendor = SupplierAcc::orderBy('id')->get();
            $customer = Customer::orderBy('id')->get();
            $category_form = Category::orderBy('parent_id', 'ASC')->get();

            $catArray = [];

            foreach ($category_form as $val) {
                $catArray[$val->parent_id][] = [
                    'id' => $val->id,
                    'cat_name' => $val->cat_name,
                    'cat_status' => $val->cat_status,
                    'parent_id' => $val->parent_id,

                ];

            }
            return view('admin.enquiry_create')->with([
                'emp' => $staff,
                'stats' => $stats,
                'vendor' => $vendor,
                'customer' => $customer,
                'category' => $catArray
            ]);
        }
        else
        {
            $request->session()->flash('not_admin','Not an admin');
            return redirect()->action('DashboardController@index');
        }
    }

    protected function store(Request $request)
    {//dd($request->enq_date);
      $this->validate($request,[
           'enq_date' => 'required',
            'rfq_number' => 'required',
//            'rbs_offer_number' => 'required',
//            'offer_value' => 'required',
            'customer' => 'required',
            'description' => 'required',
            'status' => 'required',
            'emp_id' => 'required',
            'text_remarks' => 'max:1500',
//            'catid' => 'required',
//            'vendor' => 'required'
        ]);


        $date = Carbon::createFromFormat('m/d/Y', $request->enq_date)->toDateString();
        $enquiry_man = new Enquirymanagement;
        $enquiry_man->enquiry_date =  $date;
        $enquiry_man->rfq_number = $request->rfq_number;
        $enquiry_man->rbs_offer_number = $request->rbs_offer_number;
        $enquiry_man->offer_value = $request->offer_value;
        $enquiry_man->customer = $request->customer;
        $enquiry_man->description = $request->description;
        $enquiry_man->status = $request->status;
        $enquiry_man->emp_id = $request->emp_id;
        $enquiry_man->text_remarks = $request->text_remarks;

        $enquiry_man->save();

        /*foreach($request->catid as $vval)
        {
            $enqcategory = new EnquiryCategory;
            $enqcategory->category_id = $vval;
            $enqcategory->enquiry_id = $enquiry_man->id;
            $enqcategory->save();
        }

        foreach($request->vendor as $val)
        {
            $enqvend = new EnquiryVendor;
            $enqvend->enq_id = $enquiry_man->id;
            $enqvend->vend_id = $val;
            $enqvend->status = "";
            $enqvend->description = "";
            $enqvend->save();
        }*/

        if($request->catid)
        {

            foreach($request->catid as $val)
            {
                $enq_cat = new EnquiryCategory;
                $enq_cat->category_id = $val;
                $enq_cat->enquiry_id = $enquiry_man->id;
                $enq_cat->save();
            }
        }

        if($request->vendor)
        {
            foreach($request->vendor as $val)
            {
                $enq_ven = EnquiryVendor::updateorcreate(
                    ['enq_id' => $enquiry_man->id, 'vend_id' => $val],
                    ['enq_id' => $enquiry_man->id, 'vend_id' => $val, 'status' => '', 'description' => '']
                );
            }
        }


        $request->session()->flash('enquiry_created','Your enquiry Has been successfully registered');
        return redirect()->action('EnquiryManagementController@index');



    }

    protected function edit($id)
    {
        \BREAD::putbc([
            'Enquiry' => 'rbsadmin/enquiry',
            'Edit' => '#'
        ]);

        $enq = Enquirymanagement::findorfail($id);
        $staff = User::where('urole', '2')->get();
        $status = Enquirystatus::where('id',1)->get();
        $stats = explode(",",$status[0]['status']);
        $vendor = SupplierAcc::orderBy('id')->get();
        $customer = Customer::orderBy('id')->get();

        $enqvend = EnquiryCategory::where('enquiry_id', $id)->get();

        $category_form = Category::orderBy('parent_id','ASC')->get();

        $enq_select_edit = $enq->vendors;

        $enq_vend_selc = [];
        foreach($enq_select_edit as $val)
        {
            $enq_vend_selc[] = $val->id;
        }
        $catArray = [];

        foreach ($category_form as $val)
        {
            $catArray[$val->parent_id][] = [
                'id' => $val->id,
                'cat_name' => $val->cat_name,
                'cat_status' => $val->cat_status,
                'parent_id' => $val->parent_id,

            ];

        }

        $enqajcat = [];

        foreach($enqvend as $val)
        {
            $enqajcat[] = $val->category_id;
        }

        return view('admin.enquiry_create')->with([
            'enq_edit' => $enq,
            'ven_edit' => $vendor,
            'ven_select_edit' => $enq_vend_selc,
            'stats' => $stats,
            'emp' => $staff,
            'customer' => $customer,
            'category' => $catArray,
            'category_select' => $enqajcat,
        ]);
    }

    protected function update($id, Request $request)
    {

        if(!$request['view'])
        {
            $this->validate($request, [
                'enq_date' => 'required',
                'rfq_number' => 'required',
                'description' => 'required',
                'status' => 'required',
                'emp_id' => 'required',
                'text_remarks' => 'max:1500',
                //'catid' => 'required',
                //'vendor' => 'required'
            ]);

            if (Auth::User()->urole == 1) {
                $this->validate($request, [
                    'customer' => 'required',
                ]);
            }

            $date = Carbon::createFromFormat('m/d/Y', $request->enq_date)->toDateString();

            $upd_enq = Enquirymanagement::findorfail($id);

            $upd_enq->enquiry_date = $date;
            $upd_enq->rfq_number = $request->rfq_number;
            $upd_enq->rbs_offer_number = $request->rbs_offer_number;
            $upd_enq->offer_value = $request->offer_value;
            $upd_enq->customer = $request->customer;
            $upd_enq->description = $request->description;
            $upd_enq->status = $request->status;
            $upd_enq->emp_id = $request->emp_id;
            $upd_enq->text_remarks = $request->text_remarks;

            $upd_enq->save();
        }



        if($request->catid)
        {
            $existing_category = EnquiryCategory::select('category_id')->where('enquiry_id',$id)->get();

            /***for fetching old records in db**/
            $existing_cat = [];

            foreach($existing_category as $val)
            {
               $existing_cat[] =  $val['category_id'];
            }

            /**for fetching user record and compare with old record***/

            $new_cat = [];

            foreach($request->catid as $val)
            {
                $new_cat[] = (int)$val;
            }



            $collection = collect($existing_cat);
            $diff = $collection->diff($new_cat);

            $get_deleted = $diff->all();


            EnquiryCategory::wherein('category_id',$get_deleted)->where('enquiry_id',$id)->delete();

            foreach($request->catid as $val)
            {
                $enq_cat = EnquiryCategory::updateorcreate(
                    ['category_id' => $val,'enquiry_id' => $id],
                    ['category_id' => $val,'enquiry_id' => $id]
                );
            }

        }
        else
        {
            EnquiryCategory::where('enquiry_id',$id)->delete();
        }
        if($request->vendor)
        {

            $existing_vendor = EnquiryVendor::select('vend_id')->where('enq_id',$id)->get();
            /***for fetching old records in db**/
            $existing_vend = [];

            foreach($existing_vendor as $val)
            {
                $existing_vend[] =  $val['vend_id'];
            }

            /**for fetching user record and compare with old record***/

            $new_vend = [];

            foreach($request->vendor as $val)
            {
                $new_vend[] = (int)$val;
            }

            $collection = collect($existing_vend);
            $diff = $collection->diff($new_vend);

            $get_deleted = $diff->all();

            EnquiryVendor::wherein('vend_id',$get_deleted)->where('enq_id',$id)->delete();

            $exist_vendor = EnquiryVendor::wherein('vend_id',$request->vendor)->where('enq_id',$id)->get();

            $old_vend = [];
            foreach($exist_vendor as $vval)
            {
                $old_vend[] = $vval['vend_id'];
            }

                foreach ($request->vendor as $val)
                {
                        if(!in_array($val,$old_vend))
                        {
                            $enq_vendor = new EnquiryVendor;
                            $enq_vendor->enq_id = $id;
                            $enq_vendor->vend_id = $val;
                            $enq_vendor->status = '';
                            $enq_vendor->description = '';
                            $enq_vendor->save();
                        }
                }

        }
        else
        {
            EnquiryVendor::where('enq_id',$id)->delete();
        }

        if($request['view']=="ok")
        {
            return redirect('rbsadmin/enquiry/'.$id);
        }
        else
        {
            $request->session()->flash('enquiry_updated', 'enquiry_updated');
            return redirect()->action('EnquiryManagementController@index');
        }

    }

    protected function view($id)
    {
        \BREAD::putbc([
            'Enquiry' => 'rbsadmin/enquiry',
            'View' => 'rbsadmin/enquiry/view'
        ]);

        $enq = Enquirymanagement::findorfail($id);
        $view_enquiry = Enquirymanagement::findorfail($id);
        $view_enq_vendor = $view_enquiry->vendors;
        $status = Status::where('id',1)->get();
        $stats = explode(",",$status[0]['status_vendor']);
        $staff = User::where('id',$view_enquiry->emp_id)->get();
        $staff_sel = [];

        $enq_select_edit = $enq->vendors;

        $enq_vend_selc = [];
        foreach($enq_select_edit as $val)
        {
            $enq_vend_selc[] = $val->id;
        }

        $category_form = Category::orderBy('parent_id', 'ASC')->get();

        $catArray = [];

        foreach ($category_form as $val) {
            $catArray[$val->parent_id][] = [
                'id' => $val->id,
                'cat_name' => $val->cat_name,
                'cat_status' => $val->cat_status,
                'parent_id' => $val->parent_id,

            ];

        }
        $enqvend = EnquiryCategory::where('enquiry_id', $id)->get();
        foreach($staff as $val)
        {
            $staff_sel = $val->name;
        }
        $enqajcat = [];

        foreach($enqvend as $val)
        {
            $enqajcat[] = $val->category_id;
        }

        return view('admin.enq_view')->with([
            'view_same' => $view_enquiry,
            'view_vendor' => $view_enq_vendor,
            'employee' => $staff_sel,
            'stats' => $stats,
            'category' => $catArray,
            'category_select' => $enqajcat,
            'ven_select_edit' => $enq_vend_selc,
        ]);
    }

    protected function destroy($id, Request $request)
    {
        $delete = Enquirymanagement::findOrFail($id);
        $delete->delete();

        $request->session()->flash('deleted_enquiry_successfully', 'Deleted Enquiry successfully.');

        return redirect()->action('EnquiryManagementController@index');
    }

    public function ajaxCategory(Request $request)
    {
            $categoryid = (array) json_decode($request->catdata);
            $vendors = [];
            $enqvend = Categoryshow::whereIn('cid',$categoryid)->get();
            foreach($enqvend as $enq){
                $vends = $enq->enq_vendor;
                if($vends) $vendors[$vends->id] = [$vends->company_name];

            }

        return response()->json($vendors);

    }

    public function ajaxVendor()
    {
        $ven = [];
        $vendor = SupplierAcc::orderBy('id','asc')->get();
        foreach($vendor as $val)
        {
            $ven[$val['id']] = [$val['company_name']];
        }
        return response()->json($ven);
    }

    public function save($vendorid, $enquiryid, Request $request)
    {


        $stat = EnquiryVendor::updateorcreate([
            'vend_id' => $vendorid,
            'enq_id' => $enquiryid
        ],
            [
                'status' => count($request->status_vendor) ? $request->status_vendor : 0,
                'description' => count($request->vendor_desc) ? $request->vendor_desc : "",
            ]);


        $request->session()->flash('stats_dup','statusvendupdated');
        return redirect()->action('EnquiryManagementController@view',['id' => $enquiryid]);
    }

}
