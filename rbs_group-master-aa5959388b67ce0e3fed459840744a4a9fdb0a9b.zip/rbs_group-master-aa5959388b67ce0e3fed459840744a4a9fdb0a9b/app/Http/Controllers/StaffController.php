<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Mail;
use _swiftmailer_init;
use Illuminate\Contracts\Auth\Guard;

class StaffController extends Controller
{
    private $staff_role = '';
    private $pagination_length = 50;
    public function __construct()
    {

        $this->middleware(function ($request, $next) {
            if(\Auth::user()->urole == 2)
            {
                $request->session()->flash('not_admin','Not an admin');
                return redirect()->action('DashboardController@index');
            }
            else
            {
                return $next($request);
            }
        });
        $this->staff_role = 2;
    }

    protected function index(Request $request)
    {

        \BREAD::putbc([
            'Staffs' => 'rbsadmin/staff',
        ]);
        $search = $request->search;

        $fetch =  User::where('urole', $this->staff_role);

        $req = [
            'sorting' => ['asc' => 'asc','desc' => 'desc'],
            'field' =>[
                'id' => 'id',
                'name' => 'name',
                'email' => 'email'
            ]
        ];


        $sort = $req['sorting'][($request['sort']) ? $request['sort'] : 'desc'];
        $field = $req['field'][($request['field']) ? $request['field'] : 'id'];


        $fetch = $fetch->orderBy($field,$sort);


        if($search)
        {
            $fetch = $fetch->where('name','like','%'.$search.'%')
                ->orWhere('email','like','%'.$search.'%')
                ->orWhere('id','like','%'.$search.'%');
        }
        $fetch = $fetch->paginate($this->pagination_length);
        if($request['page']==null)
        {
            $request['page'] = 1;

        }

        $page = $request['page']-1;
        $page_quer = $page * $this->pagination_length;
        return view('admin.rbsstaff')->with([
            'user' => $fetch,
            'retain_search' => $search,
            'page_quer' => $page_quer
        ]);
    }

    protected function create()
    {
        \BREAD::putbc([
            'Staffs' => 'rbsadmin/staff',
            'Add' => 'rbsadmin/staff/create',
        ]);
        return view('admin.staffcreate')->with([
            //'edit' => [],
        ]);
    }

    protected function store(Request $request)
    {
        $this->validate($request,[
            'name' => 'required|min:4|max:15',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|min:5|max:15|confirmed',
            'password_confirmation' => 'required|min:5|max:15'
        ]);

        $new_user = new User;
        $new_user->name = $request->name;
        $new_user->email = $request->email;
        $new_user->password = \Hash::make($request->password);
        $new_user->urole = $this->staff_role;
        $new_user->save();

        $data['user'] = 'RBS ADMIN';

        Mail::send('emails.welcome', $data, function($msg) {
            $msg->to("bala183651@gmail.com", "Bala_Muruga")->subject('Staff Created');
        });

        $request->session()->flash('success_new_user','New User Has Been Enrolled Successfully');

        return redirect()->action('StaffController@index');
    }

    protected function edit($id)
    {
        \BREAD::putbc([
            'Staffs' => 'rbsadmin/staff',
            'Edit' => '',
        ]);
        $user  = User::findOrFail($id);

        return view('admin.staffcreate')->with([
            'edit' => $user,
        ]);
    }

    protected function update($id, Request $request)
    {
        if($request->has('test'))
        {
            $this->validate($request,[
                'name' => 'required|min:4|max:15',
                'email' => 'required|email|max:255',
                'password' => 'required|min:5|max:15|confirmed',
                'password_confirmation' => 'required|min:5|max:15'
            ]);
        }
        else
        {
            $this->validate($request,[
                'name' => 'required|min:4|max:15',
                'email' => 'required|string|email|max:255',
            ]);
        }


        $edit_user = User::findOrFail($id);

        if($request->has('test')){
            $edit_user->name = $request->name;
            $edit_user->email = $request->email;
            $edit_user->password = \Hash::make($request->password);
            $edit_user->save();

        }
        else
        {
            $edit_user->name = $request->name;
            $edit_user->email = $request->email;
            $edit_user->save();

        }
        $request->session()->flash('success_updated_user','User Details Has Been Updated Successfully');

        return redirect()->action('StaffController@index');
    }

    protected function show($id)
    {
        //
    }

    protected function destroy($id, Request $request)
    {
        $delete = User::findOrFail($id);
        $delete->delete();

        $request->session()->flash('deleted_successfully', 'Deleted a staff details successfully.');

        return redirect()->action('StaffController@index');
    }

}
