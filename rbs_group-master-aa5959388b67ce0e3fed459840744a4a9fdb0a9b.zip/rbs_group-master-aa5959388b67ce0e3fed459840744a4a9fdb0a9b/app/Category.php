<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/4/2017
 * Time: 1:17 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    use SoftDeletes;
    protected $table = 'category';
    protected $date = ['deleted_at'];
    
}