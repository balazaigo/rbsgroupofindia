<?php

namespace App\Helper;

class BreadcrumbsHelper
{
    public static $return = [];
    public static function putbc($bread = [])
    {

        self::$return = $bread;
    }

    public static function getbc()
    {
        $land = ['Dashboard' => 'rbsadmin'];
        return array_merge($land, self::$return );
    }
}