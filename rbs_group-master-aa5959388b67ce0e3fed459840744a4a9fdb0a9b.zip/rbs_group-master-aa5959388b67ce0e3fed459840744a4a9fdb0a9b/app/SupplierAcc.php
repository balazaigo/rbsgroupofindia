<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/17/2017
 * Time: 6:55 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupplierAcc extends Model
{
    protected $table = 'supplieracc';

    public function categories()
    {
        return $this->belongsToMany('App\Category','cat','vid','cid');
    }

}