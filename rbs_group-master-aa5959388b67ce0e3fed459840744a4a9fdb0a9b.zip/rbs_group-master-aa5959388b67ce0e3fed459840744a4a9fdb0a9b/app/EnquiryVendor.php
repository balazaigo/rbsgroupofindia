<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/26/2017
 * Time: 6:47 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;


class EnquiryVendor extends Model
{
    protected $table = 'enq_vendor';
    protected $fillable = ['vend_id','enq_id','status','description'];
}