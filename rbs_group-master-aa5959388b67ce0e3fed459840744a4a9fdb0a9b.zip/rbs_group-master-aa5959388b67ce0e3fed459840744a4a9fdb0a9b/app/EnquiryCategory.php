<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class EnquiryCategory extends Model
{
    protected $table = 'enquiry_categories';
    protected $fillable = ['category_id', 'enquiry_id'];
}