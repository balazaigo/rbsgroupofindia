<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 8/23/2017
 * Time: 3:23 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseOrder extends Model
{
    protected $table = 'purchase_order';

    public function vendors()
    {
        return $this->belongsToMany('App\SupplierAcc','purchase_vendor','purchase_id','vendor_id')->withPivot('status','description');
    }

}