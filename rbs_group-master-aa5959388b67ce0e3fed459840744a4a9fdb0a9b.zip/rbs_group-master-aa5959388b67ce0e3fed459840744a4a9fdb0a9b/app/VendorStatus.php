<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 8/24/2017
 * Time: 3:53 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class VendorStatus extends Model
{
    protected $table = 'vendor_status';
    protected $fillable = ['vendor_id','enquiry_id','status','description'];
}