<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Enquirystatus extends Model
{
    protected $table = 'enquiry_status';
}