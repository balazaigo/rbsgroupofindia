<?php

namespace Tests\Unit;

use App\Enquirymanagement;
use Tests\TestCase;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\User;

class UserTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testHTTPSTATUSCODECHECK()
    {
        $response = $this->get('/');
        $response->assertStatus(200);
    }

    public function testLogin()
    {
        $user = factory(\App\User::class)->create([
            'password' => bcrypt('testpass123'),
            'urole' => '2'
        ]);

        $new = $this->call('POST','/login',['email' => $user->email,  'password' =>'testpass123',]);
            $this->assertRedirect('/rbsadmin');
            //$this->assertRedirectedTo('/rbsadmin');


        $this->assertEquals(302, $new->getStatusCode());
    }

    public function testLogout()
    {
        $response = $this->call('POST','/logout', ['_token' => csrf_token()]);
        $this->assertEquals(302, $response->getStatusCode());
    }

    /*public function testEnquiry()
    {
        $customer = factory(Enquiry::class)->create();

        $response = $this->actingAs($customer)
            ->withSession(['name' => 'bala'])
            ->post('rbsadmin/customer/create');
    }*/


}
