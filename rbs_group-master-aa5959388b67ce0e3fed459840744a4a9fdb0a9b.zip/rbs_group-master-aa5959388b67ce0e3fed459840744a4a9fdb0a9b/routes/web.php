<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['prefix' => 'form'], function(){
Route::get('form', 'FormController@index');
Route::get('create', 'FormController@create');
Route::post('form', 'FormController@store');
Route::get('form/{id}/edit', 'FormController@edit');
Route::put('form/{id}', 'FormController@update');
Route::delete('form/{id}', 'FormController@destroy');
});
/*
|--------------------------------------------------------------------------
| admin Routes
|--------------------------------------------------------------------------
*/

Route::group(['prefix' => 'rbsadmin', 'middleware' => 'auth'],function () {
    Route::get('/', 'DashboardController@index');
    /**status setting route***/
    Route::get('/status','StatusController@index');
    Route::post('/status','StatusController@store');
    /****Profile Routes***/
    Route::get('profile', 'ProfileController@index');
    Route::post('resetpassword','ProfileController@resetpassword');
    Route::post('profileupdate','ProfileController@prof_upd');

    /****Staff Routes***/
    Route::get('staff','StaffController@index');
    Route::get('staff/create','StaffController@create');
    Route::post('staff','StaffController@store');
    Route::get('staff/{id}/edit','StaffController@edit');
    Route::put('staff/{id}', 'StaffController@update');
    Route::delete('staff/{id}', 'StaffController@destroy');

    /****Category Routes***/
    Route::get('category','CategoryController@index');
    Route::get('category/create','CategoryController@create');
    Route::post('category','CategoryController@store');
    Route::get('category/{id}/edit','CategoryController@edit');
    Route::put('category/{id}','CategoryController@update');
    Route::delete('category/{id}', 'CategoryController@destroy');

    /****Form Routes***/
    Route::get('form','AdminFormController@index');
    Route::get('form/create','AdminFormController@create');
    Route::post('form','AdminFormController@store');
    Route::get('form/{id}/edit','AdminFormController@edit');
    Route::get('form/{id}','AdminFormController@view');
    Route::put('form/{id}','AdminFormController@update');
    Route::delete('form/{id}', 'AdminFormController@destroy');

    /***enquiry management routes **/
    Route::get('enquiry', 'EnquiryManagementController@index');
    Route::get('enquiry/create', 'EnquiryManagementController@create');
    Route::post('enquiry','EnquiryManagementController@store');
    Route::get('enquiry/{id}/edit','EnquiryManagementController@edit');
    Route::get('enquiry/{id}','EnquiryManagementController@view');
    Route::put('enquiry/{id}','EnquiryManagementController@update');
    Route::put('enquiry/{id}?view=ok','EnquiryManagementController@update');
    Route::delete('enquiry/{id}','EnquiryManagementController@destroy');
    Route::post('enquiry/{vendorid}/{enquiryid}','EnquiryManagementController@save');
    Route::post('enquiry/catfetch/ajax/category','EnquiryManagementController@ajaxCategory');
    Route::post('enquiry/vendfetch/ajax/vendor','EnquiryManagementController@ajaxVendor');

    /*****PO Management Routes****/
    Route::get('purchase', 'PurchaseOrderManagementController@index');
    Route::get('purchase/create', 'PurchaseOrderManagementController@create');
    Route::post('purchase','PurchaseOrderManagementController@store');
    Route::get('purchase/{id}/edit','PurchaseOrderManagementController@edit');
    Route::get('purchase/{id}','PurchaseOrderManagementController@view');
    Route::put('purchase/{id}','PurchaseOrderManagementController@update');
    Route::put('purchase/{id}?view=ok','PurchaseOrderManagementController@update');
    Route::delete('purchase/{id}','PurchaseOrderManagementController@destroy');
    Route::post('purchase/{vendorid}/{purchaseid}','PurchaseOrderManagementController@save');
    Route::post('purchase/vendupd/ajax/category','PurchaseOrderManagementController@ajaxCategory');
    /**********Customer Module Routes*****/
    Route::get('customer', 'CustomerController@index');
    Route::get('customer/create', 'CustomerController@create');
    Route::post('customer','CustomerController@store');
    Route::get('customer/{id}/edit','CustomerController@edit');
    Route::get('customer/{id}','CustomerController@view');
    Route::put('customer/{id}','CustomerController@update');
    Route::delete('customer/{id}','CustomerController@destroy');
});

Auth::routes();

